import os
import win32security
import win32api
import ntsecuritycon as con
from cryptography.fernet import Fernet

def set_file_permissions(file_path):
    """
    设置文件权限，使得只有当前用户和系统用户可以访问和修改文件，
    拒绝所有其他用户访问的权限。
    """
    try:
        user, domain, type = win32security.LookupAccountName("", win32api.GetUserName())
        system_user, domain, type = win32security.LookupAccountName("", "SYSTEM")

        sd = win32security.GetFileSecurity(file_path, win32security.DACL_SECURITY_INFORMATION)
        dacl = win32security.ACL()

        dacl.AddAccessAllowedAce(win32security.ACL_REVISION, con.FILE_ALL_ACCESS, system_user)
        dacl.AddAccessAllowedAce(win32security.ACL_REVISION, con.FILE_GENERIC_READ | con.FILE_GENERIC_WRITE, user)
        everyone, domain, type = win32security.LookupAccountName("", "Everyone")
        dacl.AddAccessDeniedAce(win32security.ACL_REVISION, con.FILE_ALL_ACCESS, everyone)
        
        sd.SetSecurityDescriptorDacl(1, dacl, 0)
        win32security.SetFileSecurity(file_path, win32security.DACL_SECURITY_INFORMATION, sd)

    except Exception as e:
        print(f"Error setting permissions for {file_path}: {e}")

def create_secure_file(file_path, data):
    """
    创建文件并写入数据，同时设置文件权限。
    """
    with open(file_path, 'wb') as file:
        file.write(data)
    set_file_permissions(file_path)

program_data_storage_directory = os.path.join(os.path.expanduser("~"), "AppData", "Roaming", "Python_Random_Select")
os.makedirs(program_data_storage_directory, exist_ok=True)

num = 1
list_name = f"list_{num}.enc"
key_name = f"ksy_{num}.key"
list_path = os.path.join(program_data_storage_directory, list_name)
key_path = os.path.join(program_data_storage_directory, key_name)

Fernet_key = Fernet.generate_key()
data = 'example_data'
fernet = Fernet(Fernet_key)
encrypted_data = fernet.encrypt(data.encode())

create_secure_file(key_path, Fernet_key)
create_secure_file(list_path, encrypted_data)
