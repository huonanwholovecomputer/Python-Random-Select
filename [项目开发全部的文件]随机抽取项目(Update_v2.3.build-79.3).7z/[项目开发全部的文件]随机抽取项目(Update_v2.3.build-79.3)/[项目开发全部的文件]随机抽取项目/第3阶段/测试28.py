import random
from collections import Counter

e = ["刘奕含","郝晔妮","王慧娟","马跃","窦可冉","马佳雪","袁博","刘杰","张宇航","霍楠","张浩然","杨慧仪","马玲丹","高怡浩","张靖雨","李芊雨","朱佳乐","陈玉","雷航","李媛媛","苗夏雨","马赫","张坤","郝浩然","王文涛","王浩宇","崔知轩","雷淼","米庆","王美丹","马润杰","刘于楠","雷文杰","白宇杰","罗佳庚","贺佳美","王欣瑜","王浩森","马谢楠","李泽翔", "王森", "崔欣悦", "雷旭阳", "霍俞达","王玙贴","任璠","胡峰","张翔荣"]
percentage_format = "{:.1%}"

valid_selections = set()  # 记录有效选取的元素

while len(valid_selections) < 5:  # 进行5次有效选取
    n = random.randint(50, 100)
    random_e = random.choices(e, k=n)
    e_counts = Counter(random_e)
    total_occurrences = sum(e_counts.values())
    sorted_e = sorted(e_counts.items(), key=lambda x: x[1], reverse=True)

    # 判断当前循环是否产生了有效选取
    current_selections = set(e for (e, _) in sorted_e[:2])  # 取出频次最高的两个元素
    if current_selections != valid_selections:  # 如果和上一次的有效选取不同，则是有效选取
        valid_selections = current_selections  # 更新有效选取
        for (e, count) in sorted_e:
            percentage = count / total_occurrences
            formatted_percentage = percentage_format.format(percentage)
            print(f"{e}:{count}；{formatted_percentage}")
        most_common_count = sorted_e[0][1]
        most_common_e = [e for (e, count) in sorted_e if count == most_common_count]
        print("出现最频繁的元素:")
        for e in most_common_e:
            print(f"【{e}】")
    else:
        print("当前循环中未出现有效选取")
    
print("已完成5次有效选取，退出程序。")
