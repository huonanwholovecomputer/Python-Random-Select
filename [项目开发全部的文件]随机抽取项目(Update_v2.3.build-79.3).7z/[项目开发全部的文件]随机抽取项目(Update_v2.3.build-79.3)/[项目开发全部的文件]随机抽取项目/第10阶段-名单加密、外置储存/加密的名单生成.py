from cryptography.fernet import Fernet

# 生成密钥
Fernet_key = Fernet.generate_key()

# 提示用户输入密码并进行确认
password = input('Set a password for encrypting list2: ')
verify_password = input('Verify password: ')

if password != verify_password:
    print("Passwords do not match!")
else:
    # 保存密钥到文件
    with open('Fernet_key.key', 'wb') as Fernet_key_file:
        Fernet_key_file.write(Fernet_key)

    # 示例列表数据
    list2 = ['Alice', 'Bob', 'Charlie', 'David']
    data = '\n'.join(list2)

    # 加密数据
    fernet = Fernet(Fernet_key)
    encrypted_data = fernet.encrypt(data.encode())

    # 保存加密后的数据到文件
    with open('list2.enc', 'wb') as file:
        file.write(encrypted_data)

    print("list2 has been encrypted and saved to 'list2.enc'")
