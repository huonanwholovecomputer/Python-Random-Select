import random

a = random.randint(1000, 10000)
print(a)
