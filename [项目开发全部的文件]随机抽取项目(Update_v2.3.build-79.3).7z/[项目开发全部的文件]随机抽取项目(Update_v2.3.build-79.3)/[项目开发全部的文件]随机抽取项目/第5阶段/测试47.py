import random
import time
c=input("输入值开始抽取...")
count = 0
while True:
    count += 1
    if count <= 5:
        students = ["学生1","学生2","学生3","学生4","学生5","学生6","学生7","学生8","学生9"]
        selection_counts = {student: 0 for student in students}
        print("--------------------------")
        a = random.randint(1000, 10000)
        num_students = int(a)
        counter = 0
        while counter < max_iterations:
            random_student = random.choice(students)
            selection_counts[random_student] += 1
            counter += 1
        print("")
        total_count = sum(selection_counts.values())
        sorted_selection_counts = sorted(selection_counts.items(), key=lambda x: x[1])
        for student, count in sorted_selection_counts:
            percentage = count / total_count * 100
            print(f"{student}: 被抽取次数：{count} 次 ；所占总数比例：({percentage:.2f}%)")
        print("--------------------------------------------------------")
        print("抽取结束")
        print("本次随机抽取的的随机抽取次數：", end="")
        print(a)
        print("以上是所有学生抽的取次数统计（从小到大排列）：")
    max_student, max_count = sorted_selection_counts[-1]
    print("本次被抽取次數最高的学生：", end="")
    print(f"【{max_student}】: {max_count} 次")
    else:
        break
