import random
import time

students = ["刘奕含","郝晔妮","王慧娟","马跃","窦可冉","马佳雪","袁博","刘杰","张宇航","杨慧仪","马玲丹","高怡浩","张靖雨","李芊雨","朱佳乐","陈玉","雷航","李媛媛","苗夏雨","马赫","张坤","郝浩然","王文涛","王浩宇","崔知轩","雷淼","米庆","王美丹","马润杰","刘于楠","雷文杰","白宇杰","罗佳庚","贺佳美","王欣瑜","王浩森","马谢楠","李泽翔", "王森", "崔欣悦", "雷旭阳", "霍俞达","王玙贴","任璠","胡峰","张翔荣"]
selection_counts = {student: 0 for student in students}
    print("")
    print("--------------------------------------------------")
    a = random.randint(1000, 10000)
    num_students = int(a)
    counter = 0
    max_iterations = num_students
    while counter < max_iterations:
        random_student = random.choice(students)
        selection_counts[random_student] += 1
        counter += 1
    total_count = sum(selection_counts.values())
    sorted_selection_counts = sorted(selection_counts.items(), key=lambda x: x[1])
    for student, count in sorted_selection_counts:
        percentage = count / total_count * 100
    print(f"{student}: {count} 次 ({percentage:.2f}%)")
    print("")
    print("抽取结束！")
    print("")
    print("以上是:所有学生抽取次数统计")
    print("本次共抽取：", end="")
    print(a,end="")
    print("次")
    print("")
    print("被抽取次数最高的学生：")
    max_student, max_count = sorted_selection_counts[-1]
    print("")
    print(f"【{max_student}】: {max_count} 次")
