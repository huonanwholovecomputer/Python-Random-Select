import random
import time

students = ["學生1", "學生2", "學生3", "學生4", "學生5", "學生6", "學生7", "學生8", "學生9"]

selection_counts = {student: 0 for student in students}

print("")
print("--------------------------")
a = random.randint(1000, 10000)
print("本次隨機的抽取次數：", end="")
print(a)
num_students = int(a)
counter = 0
max_iterations = num_students
while counter < max_iterations:
    random_student = random.choice(students)
    selection_counts[random_student] += 1
    counter += 1
print("")
print("抽取結束")
print("學生抽取次數統計：")
for student, count in selection_counts.items():
    print(f"{student}: {count} 次")
