import random
import time

students = ["学生1","学生2","学生3","学生4","学生5","学生6","学生7","学生8","学生9"]
selection_counts = {student: 0 for student in students}

print("")
print("--------------------------")
a = random.randint(1000, 10000)
print("本次隨機的抽取次數：", end="")
print(a)

num_students = int(a)
counter = 0
max_iterations = num_students

while counter < max_iterations:
    random_student = random.choice(students)
    selection_counts[random_student] += 1
    counter += 1

print("")
print("抽取結束")
print("")
print("所有学生抽取次数统计：")
print("")
total_count = sum(selection_counts.values())
sorted_selection_counts = sorted(selection_counts.items(), key=lambda x: x[1])

for student, count in sorted_selection_counts:
    percentage = count / total_count * 100
    print(f"{student}: {count} 次 ({percentage:.2f}%)")
