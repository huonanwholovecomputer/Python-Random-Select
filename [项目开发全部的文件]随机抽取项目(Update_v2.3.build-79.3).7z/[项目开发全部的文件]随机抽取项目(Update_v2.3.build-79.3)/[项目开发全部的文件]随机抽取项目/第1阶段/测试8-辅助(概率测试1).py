import random

students = ["學生1", "學生2"]
count = 100
results = []

for _ in range(count):
    if len(students) > 0:
        random_students = random.sample(students, len(students))
        results.append(random_students)

for i, random_students in enumerate(results):
    print(f"第 {i+1} 次隨機抽取的學生：{random_students}")
