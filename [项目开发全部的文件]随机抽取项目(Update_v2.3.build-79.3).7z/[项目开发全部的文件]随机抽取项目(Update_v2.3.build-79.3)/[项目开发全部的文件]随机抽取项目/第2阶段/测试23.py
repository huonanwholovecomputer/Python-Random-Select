import random
from collections import Counter

elements = ['a', 'b', 'c', 'd', 'e']

m = int(input("請輸入累計個數m："))
element_counts = Counter()
total_counted = 0

while total_counted < m:
    n = random.randint(50, 100)  
    random_elements = random.choices(elements, k=n)
    element_counts.update(random_elements)
    total_counted = sum(1 for count in element_counts.values() if count > 0)

total_occurrences = sum(element_counts.values())

sorted_elements = sorted(element_counts.items(), key=lambda x: x[1], reverse=True)

for element, count in sorted_elements:
    percentage = count / total_occurrences
    formatted_percentage = "{:.1%}".format(percentage)
    print(f"{element}: {count}；{formatted_percentage}")

most_common_elements = [element for element, count in element_counts.most_common(m)]

print("次數最高的元素:")
for element in most_common_elements:
    print(f"【{element}】")
print(f"內部循環次數n: {n}")
print("----------------")
