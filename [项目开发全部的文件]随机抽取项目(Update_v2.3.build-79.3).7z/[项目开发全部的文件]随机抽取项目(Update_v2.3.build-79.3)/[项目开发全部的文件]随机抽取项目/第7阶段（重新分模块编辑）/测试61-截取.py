# 输出“随机抽取，启动！”
sentence = "随机抽取，启动！"
for char in sentence:
    print(char, end="")
    sys.stdout.flush()
    if char in ["，", "！"]:
        time.sleep(0.5)
    else:
        time.sleep(0.05)
# 选择函数部分：
def get_choice():
    while True:
        print("")
        print("请选择运行选项：")
        print("")
        print("【1】 英语课专用（无日语学生）")
        print("")
        print("【2】 常规（全体学生）")
        print("")
        print("【3】 帮助（也可输入“？”、“?”）")
        key = msvcrt.getch()
        if key == b"1":  # 注意这里的比较值应为字节串
            print("")
            sentence = "已选择【1】，进入：英语课专用的随机抽取(无日语学生)"
            for char in sentence:
                print(char, end="")
                sys.stdout.flush()
                time.sleep(0.05)
            time.sleep(1)
            print("")
            students = students_1
            break
        elif key == b"2":  # 注意这里的比较值应为字节串
            print("")
            sentence = "已选择【2】，进入：常规随机抽取(全体学生)"
            for char in sentence:
                print(char, end="")
                sys.stdout.flush()
                time.sleep(0.05)
            time.sleep(1)
            print("")
            students = students_2
            break
        elif key == b"3"or"?"or"？":
            print("")
            sentence = "已选择【3】，帮助：输入1或者2，进入指定的抽取模式"
            for char in sentence:
                print(char, end="")
                sys.stdout.flush()
                time.sleep(0.05)
            print("")
            time.sleep(1)
        else:
            print("")
            print("无效选择！")
            time.sleep(1)
            print("")
            print("请重新选择！")
            time.sleep(0.5)
    
get_choice()  # 调用 get_choice() 函数

