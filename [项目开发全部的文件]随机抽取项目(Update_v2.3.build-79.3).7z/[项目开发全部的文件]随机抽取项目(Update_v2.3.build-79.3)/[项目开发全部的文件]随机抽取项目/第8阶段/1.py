# 随机函数
import random
# 时间函数
import time
# 打字函数
import sys
# 选择函数
import msvcrt
while True:
    while True:
        while True:
            while True:
                while True:
                    while True:
                        students = ["白宇杰","陈俊昌","陈玉","崔欣悦","崔知轩","窦可冉","高怡浩","韩敬哲","韩怡悦","郝浩然","郝晔妮","贺佳美","胡峰","霍楠","霍俞达","雷航","雷淼","雷旭阳","李芊雨","李媛媛","李泽翔","刘杰","刘奕含","刘于楠","马赫","马佳雪","马玲丹","马润杰","马谢楠","马跃","米庆","苗夏雨","任璠","王浩森","王浩宇","王慧娟","王美丹","王森","王文涛","王欣瑜","王玙贴","杨慧仪","袁博","张靖雨","张坤","张翔荣","张宇航","张雨萌","朱佳乐"]
                        # 如果输入非负整数
                        print("")
                        b = (input("需要抽取的学生个数："))
                        if b.isdigit():
                            num_students_b = int(b)
                            if num_students_b > len(students):
                                print("提示：需要抽取的学生个数超过学生总数！")
                                time.sleep(0.1)
                                print("")
                                print("请重新抽取..")
                                time.sleep(0.2)
                            else:
                                print("")
                                print("")
                                print("---------------------------------------------")
                                c = 0
                                e = 1
                                b = int(b)
                                selection_students = []
                                while c < b:
                                    c += 1
                                    e += 1
                                    selection_counts = {student: 0 for student in students}
                                    a = random.randint(10000, 100000)
                                    time.sleep(1)
                                    print("")
                                    print("本次随机抽取的的随机s抽取次数：", end="")
                                    print(a, end="")
                                    print("次")
                                    print("")
                                    time.sleep(1)
                                    num_students = int(a)
                                    counter = 0
                                    max_iterations = num_students
                                    while counter < max_iterations:
                                        random_student = random.choice(students)
                                        selection_counts[random_student] += 1
                                        counter += 1
                                    print("")
                                    total_count = sum(selection_counts.values())
                                    sorted_selection_counts = sorted(selection_counts.items(), key=lambda x: -x[1])
                                    position = 1
                                    for student, count in sorted_selection_counts:
                                        percentage = count / total_count * 100
                                        print("第",position,"名",end="：")
                                        print(f"{student}: 被抽取次数：{count} 次 ；频率：({percentage:.3f}%)")
                                        position +=1
                                        # 生成一个介于1到学生总数之间的随机数x
                                        print("")
                                    x = random.randint(1, len(students))
                                    print("本次选择的学生是排名为第",x,"名的学生")
                                    print("")
                                    # 获取排名为x的学生
                                    max_student, max_count = sorted_selection_counts[x - 1]
                                    print("")
                                    print("本次选中的学生：", end="")
                                    print(f"【{max_student}】；次数：{max_count} 次；频率：{percentage:.3f}%")
                                    print("")
                                    print("第", c, "次抽取结束！")
                                    time.sleep(0.5)
                                    print("正在决定是否开启第", e,"次抽取...")
                                    time.sleep(1)
                                    print("")
                                    if max_student in selection_students:
                                        b += 1
                                        print("")
                                        sentence = "抽取过程中出现重复的学生，准备重新抽取"
                                        for char in sentence:
                                            print(char, end="")
                                            sys.stdout.flush()
                                            time.sleep(0.05)
                                        time.sleep(1)
                                    else:
                                        selection_students.append(max_student)
                                    if selection_students.count(max_student) > 1:
                                        selection_students.remove(max_student)
                                print("")
                                print("最终的抽取结果：",selection_students)
                                print("")
