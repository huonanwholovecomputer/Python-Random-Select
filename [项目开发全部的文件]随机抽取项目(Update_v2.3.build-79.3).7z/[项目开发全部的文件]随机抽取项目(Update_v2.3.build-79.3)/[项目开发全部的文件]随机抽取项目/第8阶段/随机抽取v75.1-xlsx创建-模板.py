import pandas as pd
import random
from pathlib import Path

# 初始化变量
students = ["学生1", "学生2", "学生3", "学生4", "学生5", "学生6", "学生7", "学生8"]
excel_file_path = Path('students_xlsx.xlsx')

# 随机选择学生
s_students = random.choice(students)

# 打印集合
print(f"Selected student: {s_students}")

# 读取或创建Excel文件
if excel_file_path.is_file():
    # 读取现有Excel文件
    df = pd.read_excel(excel_file_path, index_col=0)
else:
    # 创建新的DataFrame
    df = pd.DataFrame(columns=['Count'])

# 检查学生是否已在DataFrame中
if s_students in df.index:
    # 学生已存在，增加计数
    df.at[s_students, 'Count'] += 1
else:
    # 学生不在DataFrame中，添加学生
    df = pd.concat([df, pd.DataFrame({'Count': [1]}, index=[s_students])])

# 将数据写入Excel文件
with pd.ExcelWriter(excel_file_path, engine='openpyxl') as writer:
    df.to_excel(writer, sheet_name='Counts')
    if not writer.sheets or 'Student List' not in writer.sheets:
        # 如果"Student List"表不存在则创建
        pd.DataFrame({'Student Names': students}).to_excel(writer, sheet_name='Student List', index=False)

print(f"Updated records for: {s_students}")
