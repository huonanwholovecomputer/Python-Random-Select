import random
import time

students = ["刘奕含","郝晔妮","王慧娟","马跃","窦可冉","马佳雪","袁博","刘杰","张宇航","霍楠","张浩然","杨慧仪","马玲丹","高怡浩","张靖雨","李芊雨","朱佳乐","陈玉","雷航","李媛媛","苗夏雨","马赫","张坤","郝浩然","王文涛","王浩宇","崔知轩","雷淼","米庆","王美丹","马润杰","刘于楠","雷文杰","白宇杰","罗佳庚","贺佳美","王欣瑜","王浩森","马谢楠","李泽翔", "王森", "崔欣悦", "雷旭阳", "霍俞达","王玙贴","任璠","胡峰","张翔荣"]

while True:
    print("")
    print("--------------------------")
    y = input("請輸入抽取次數：")
    m=1

    if y.isdigit():
        num_students_n = int(y)

        if num_students_n > len(students):
            print("")
            print("提示：抽取數量超過學生總數！")
            time.sleep(1)
            print("")
            print("請重新抽取..")
            time.sleep(1.5)
        else:
            counter = 0
            max_iterations = num_students_n

            while counter < max_iterations:
                random_students = random.sample(students, num_students_n)
                print("")
                print("本次隨機抽取的學生：", random_students)
                time.sleep(0.5)
                print("")
                print("等待..")
                time.sleep(1)
                counter += 1

            print("循環已停止")
    else:
        print("")
        print("提示：請輸入一個正整數！")
