elif d.isdigit():
        num_students_d = int(d)
        if num_students_d > len(students):
            print("")
            print("提示：抽取抽取数量超过学生总数！")
            time.sleep(1)
            print("")
            print("请重新抽取..")
            time.sleep(1.5)
        else:
          c = 0
          max_students = []
          while c < num_students_d:
            c += 1
            selection_counts = {student: 0 for student in students}
            a = random.randint(1000, 10000)
            num_students = int(a)
            counter = 0
            max_iterations = num_students
            while counter < max_iterations:
              random_student = random.choice(students)
              selection_counts[random_student] += 1
              counter += 1
            total_count = sum(selection_counts.values())
            sorted_selection_counts = sorted(selection_counts.items(), key=lambda x: x[1])
            for student, count in sorted_selection_counts:
                percentage = count / total_count * 100
            max_student, max_count = sorted_selection_counts[-1]
            if max_student in max_students:
                num_students_d += 1
            else:
                max_students.append(max_student)
            if max_students.count(max_student) > 1:
                max_students.remove(max_student)
          print("")
          print("抽取结果：", max_students)
    elif d =='？':
       print('提示信息')
