from cryptography.fernet import Fernet
import getpass

# 生成密钥
key = Fernet.generate_key()

# 提示用户输入密码并进行确认
password = getpass.getpass(prompt='Set a password for encrypting list2: ')
verify_password = getpass.getpass(prompt='Verify password: ')

if password != verify_password:
    print("Passwords do not match!")
else:
    # 保存密钥到文件
    with open('key.key', 'wb') as key_file:
        key_file.write(key)

    # 示例列表数据
    list2 = ['Alice', 'Bob', 'Charlie', 'David']
    data = '\n'.join(list2)

    # 加密数据
    fernet = Fernet(key)
    encrypted_data = fernet.encrypt(data.encode())

    # 保存加密后的数据到文件
    with open('list2.enc', 'wb') as file:
        file.write(encrypted_data)

    print("list2 has been encrypted and saved to 'list2.enc'")

# 读取和解密数据
# 读取密钥
with open('key.key', 'rb') as key_file:
    key = key_file.read()

# 读取加密的数据
with open('list2.enc', 'rb') as encrypted_file:
    encrypted_data = encrypted_file.read()

# 创建 Fernet 对象
fernet = Fernet(key)

# 解密数据
decrypted_data = fernet.decrypt(encrypted_data)

# 将解密后的数据转换回字符串
data = decrypted_data.decode()

# 将字符串数据转换回列表
list2 = data.split('\n')

print("Decrypted list2:", list2)
