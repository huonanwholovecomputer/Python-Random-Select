import os
import datetime
import random
import time
from cryptography.fernet import Fernet

# 创建程序储存目录
program_data_storage_directory = os.path.join(os.path.expanduser("~"), "AppData", "Roaming", "Python_Random_Select")
os.makedirs(program_data_storage_directory, exist_ok=True)

# 定义环境变量、文件路径
Fernet_key_name = "Fernet_key.dll"
Fernet_key_path = os.path.join(program_data_storage_directory, Fernet_key_name)
recorded_students_file_name = "recorded_students.dll"
recorded_students_file_path = os.path.join(program_data_storage_directory, recorded_students_file_name)

# 定义函数write_recorded_students(selection_student, now):
def write_recorded_students(selection_student, now):
    with open(Fernet_key_path, "rb") as key_file:
        Fernet_key = key_file.read()
    fernet = Fernet(Fernet_key)
    
    # 读取现有记录
    if os.path.exists(recorded_students_file_path):
        with open(recorded_students_file_path, "rb") as data_file:
            encrypted_data = data_file.read()
        decrypted_data = fernet.decrypt(encrypted_data).decode()
    else:
        decrypted_data = ""
    
    # 添加新的记录
    selection_student_and_now = selection_student + " " + now.strftime("%Y-%m-%d %H:%M:%S") + "\n"
    decrypted_data += selection_student_and_now
    
    # 加密并写入文件
    encrypted_data = fernet.encrypt(decrypted_data.encode())
    with open(recorded_students_file_path, "wb") as data_file:
        data_file.write(encrypted_data)

# 定义函数read_recorded_students():
def read_recorded_students():
    if os.path.exists(recorded_students_file_path):
        with open(Fernet_key_path, "rb") as key_file:
            Fernet_key = key_file.read()
        fernet = Fernet(Fernet_key)
        with open(recorded_students_file_path, "rb") as data_file:
            encrypted_data = data_file.read()
        decrypted_data = fernet.decrypt(encrypted_data).decode()
        recorded_students = [line.split(' ')[0] for line in decrypted_data.strip().split('\n')]
        return recorded_students
    return []

# 示例学生名单
students_list = ["Alice", "Bob", "Charlie", "David", "Eve", "Frank"]

while True:
    students = students_list
    if os.path.exists(recorded_students_file_path):
        recorded_students = read_recorded_students()
        students = [student for student in students if student not in recorded_students]
    
    A = input("\n请输入需要抽取的学生个数：")
    
    # 抽取部分
    time.sleep(0.5)
    
    if A.isdigit():
        cycle_count = 0
        number_of_shuffles = 0
        A = int(A)
        if A > len(students):
            print("\n提示：需要抽取的学生个数超过学生总数！")
            time.sleep(0.1)
            print("\n请重新抽取..")
            time.sleep(0.2)
        else:
            selection_students = []
            if A <= 6:
                random.shuffle(students)
                while cycle_count < A:
                    cycle_count += 1
                    selection_student = random.choice(students)
                    if selection_student in selection_students:
                        A += 1
                    else:
                        selection_students.append(selection_student)
                        now = datetime.datetime.now()
                        write_recorded_students(selection_student, now)
            else:
                while cycle_count < A:
                    random.shuffle(students)
                    cycle_count += 1
                    if cycle_count % 5 == 0:
                        number_of_shuffles += 1
                        random.shuffle(students)
                    selection_student = random.choice(students)
                    if selection_student in selection_students:
                        A += 1
                    else:
                        selection_students.append(selection_student)
                        now = datetime.datetime.now()
                        write_recorded_students(selection_student, now)
            print(f"\n抽取结果：【{selection_students}】")
