import random

b = int(input("請輸入一個數字："))
c = 0
d = 0
max_students = []  # 保存被抽取次數最高的學生名字的列表

while c < b:
    c += 1
    d += 1
    students = ["學生1", "學生2", "學生3", "學生4", "學生5", "學生6", "學生7", "學生8", "學生9"]
    selection_counts = {student: 0 for student in students}
    a = random.randint(1000, 10000)
    num_students = int(a)
    counter = 0
    max_iterations = num_students
    while counter < max_iterations:
        random_student = random.choice(students)
        selection_counts[random_student] += 1
        counter += 1
    print("")
    total_count = sum(selection_counts.values())
    sorted_selection_counts = sorted(selection_counts.items(), key=lambda x: x[1])
    for student, count in sorted_selection_counts:
        percentage = count / total_count * 100
        print(f"{student}: 被抽取次数：{count} 次 ；所占总数比例：({percentage:.3f}%)")
    max_student_d, max_count = sorted_selection_counts[-1]
    max_students.append(max_student_d)  # 將本次循環中被抽取次數最高的學生名字添加到列表中
    print("第", c, "次抽取结束！")
    print("本次随机抽取的的随机抽取次數：", end="")
    print(a)
    print("以上是所有学生抽的取次数统计（从小到大排列）：")
    print("本次被抽取次數最高的學生：", end="")
    print(f"【{max_student_d}】；次數：{max_count} 次；佔總抽取次數百分比：{percentage:.3f}%")
print("--------------------------------------------------------")
print("")
print("所有循環中被抽取次數最高的學生名字：", max_students)
