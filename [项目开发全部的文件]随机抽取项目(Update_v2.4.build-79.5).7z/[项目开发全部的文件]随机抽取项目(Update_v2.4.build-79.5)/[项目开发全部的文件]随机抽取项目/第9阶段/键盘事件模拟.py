import pyautogui
import time

time.sleep(2)
# 定义循环次数
num_cycles = 73

for _ in range(num_cycles):
    # 模拟按下“下”键
    pyautogui.press('down')
    # 等待一秒钟
    time.sleep(0.01)

    # 模拟按下“Home”键
    pyautogui.press('home')
    # 等待一秒钟
    time.sleep(0.01)

    # 模拟按下“Tab”键
    pyautogui.press('tab')
    # 等待一秒钟
    time.sleep(0.01)
