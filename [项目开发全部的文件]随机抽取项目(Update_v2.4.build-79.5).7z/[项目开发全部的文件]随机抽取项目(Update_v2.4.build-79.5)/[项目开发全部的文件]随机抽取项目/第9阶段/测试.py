s = "随机抽取，启动！"
for char in s:
    print(char, end="")
    sys.stdout.flush()
    if char in ["，", "！"]:
        time.sleep(0.5)
    else:
        time.sleep(0.02)
