from colorama import init, Fore
import time

init()

def print_typewriter(本程序的运行机制是，随机抽取一个学生，抽取一定次数（抽取次数是1千到1万的随机数）后，抽取完成之后，统计每个学生的被抽取次数、被抽取率（本次被抽取的次数与总抽取次数的百分比），选择被抽取次数最多的学生作为本次选中的学生。 输入需要的学生数量，就循环多少次):
    for char in text:
        print(char, end='', flush=True)
        time.sleep(0.1)

sentence = "Hello, world! This is typewriter effect."

print_typewriter(sentence)
