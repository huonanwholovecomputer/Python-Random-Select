students = ["白宇杰","陈玉","崔欣悦","崔知轩","窦可冉","冯宇乐","高怡浩","郝浩然","郝晔妮","贺佳美","胡峰","霍楠","霍俞达","雷航","雷淼","雷文杰","雷旭阳","李芊雨","李媛媛","李泽翔","刘杰","刘奕含","刘于楠","罗佳庚","马赫","马佳雪","马玲丹","马润杰","马谢楠","马跃","米庆","苗夏雨","任璠","王浩森","王浩宇","王慧娟","王美丹","王森","王文涛","王欣瑜","王玙贴","杨慧仪","袁博","张靖雨","张坤","张文杰","张翔荣","张宇航","朱佳乐"]
b = int(input("请输入需要抽取的学生人數："))
c = 0
max_students = []
while c < b:
    c += 1
    students = ["學生1", "學生2", "學生3", "學生4", "學生5", "學生6", "學生7", "學生8", "學生9"]
    
    selection_counts = {student: 0 for student in students}
    a = random.randint(1000, 10000)
    num_students = int(a)
    counter = 0
    max_iterations = num_students
    while counter < max_iterations:
        random_student = random.choice(students)
        selection_counts[random_student] += 1
        counter += 1
    print("")
    total_count = sum(selection_counts.values())
    sorted_selection_counts = sorted(selection_counts.items(), key=lambda x: x[1])
    for student, count in sorted_selection_counts:
        percentage = count / total_count * 100
        print(f"{student}: 被抽取次数：{count} 次 ；所占总数比例：({percentage:.3f}%)")
    max_student, max_count = sorted_selection_counts[-1]
    max_students.append(max_student)  # 將本次循環中被抽取次數最高的學生名字添加到列表中
    print("第", c, "次抽取结束！")
    print("本次随机抽取的的随机抽取次數：", end="")
    print(a)
    print("以上是所有学生抽的取次数统计（从小到大排列）：")
    print("本次被抽取次數最高的學生：", end="")
    print(f"【{max_student}】；次數：{max_count} 次；佔總抽取次數百分比：{percentage:.3f}%")
print("--------------------------------------------------------")
print("")
print("所有循環中被抽取次數最高的學生名字：", max_students)
