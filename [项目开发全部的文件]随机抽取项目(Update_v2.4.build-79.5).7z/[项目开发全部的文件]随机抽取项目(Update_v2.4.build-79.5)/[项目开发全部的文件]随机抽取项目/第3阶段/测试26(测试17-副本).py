import random
from collections import Counter

elements = ['a', 'b', 'c', 'd', 'e']

percentage_format = "{:.1%}"

while effective_selections < 5:
    n = random.randint(50, 100)

    random_elements = random.choices(elements, k=n)
    element_counts = Counter(random_elements)

    total_occurrences = sum(element_counts.values())

    sorted_elements = sorted(element_counts.items(), key=lambda x: x[1], reverse=True)

    for element, count in sorted_elements:
        percentage = count / total_occurrences
        formatted_percentage = percentage_format.format(percentage)
        print(f"{element}:{count}；{formatted_percentage}")

    most_common_count = sorted_elements[0][1]
    most_common_elements = [element for element, count in sorted_elements if count == most_common_count]

    print("次數最高的元素:")
    for element in most_common_elements:
        print(f"【{element}】")
