import random
from collections import Counter

e = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'z']
percentage_format = "{:.1%}"
effective_selections = 0

while effective_selections < 5:
    n = random.randint(50, 100)
    random_e = random.choices(e, k=n)
    e_counts = Counter(random_e)
    total_occurrences = sum(e_counts.values())
    sorted_e = sorted(e_counts.items(), key=lambda x: x[1], reverse=True)
    previous_e = None

    for e, count in sorted_e:
        if e != previous_e:
            effective_selections += 1
            previous_e = e
        else:
            continue

        percentage = count / total_occurrences
        formatted_percentage = percentage_format.format(percentage)
        print(f"{e}:{count}；{formatted_percentage}")

        if effective_selections >= 5:
            break

    if effective_selections >= 5:
        break

    most_common_count = sorted_e[0][1]
    most_common_e = [e for e, count in sorted_e if count == most_common_count]
    print("次數最高的元素:")
    for e in most_common_e:
        print(f"【{e}】")
