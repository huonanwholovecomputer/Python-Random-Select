import random
from collections import Counter

e = ['a', 'b']
percentage_format = "{:.1%}"

valid_selections = set()  # 记录有效选取的元素

iteration_count = 0  # 记录进行了多少次循环

while len(valid_selections) < 5 and iteration_count < 100:  # 进行5次有效选取或超过100次循环则退出
    n = random.randint(50, 100)
    random_e = random.choices(e, k=n)
    e_counts = Counter(random_e)
    total_occurrences = sum(e_counts.values())
    sorted_e = sorted(e_counts.items(), key=lambda x: x[1], reverse=True)

    # 判断当前循环是否产生了有效选取
    current_selections = set(e for (e, _) in sorted_e[:2])  # 取出频次最高的两个元素
    if current_selections != valid_selections:  # 如果和上一次的有效选取不同，则是有效选取
        valid_selections = current_selections  # 更新有效选取
        for (e, count) in sorted_e:
            percentage = count / total_occurrences
            formatted_percentage = percentage_format.format(percentage)
            print(f"{e}:{count}；{formatted_percentage}")
        most_common_count = sorted_e[0][1]
        most_common_e = [e for (e, count) in sorted_e if count == most_common_count]
        print("出现最频繁的元素:")
        for e in most_common_e:
            print(f"【{e}】")
    else:
        print("当前循环中未出现有效选取")

    iteration_count += 1  # 每次循环计数器加1
    
print("已完成5次有效选取或超过100次循环，程序退出。")
