import random
from collections import Counter

elements = ['a', 'b', 'c', 'd', 'e']

n = random.randint(50, 100)

random_elements = random.choices(elements, k=n)
element_counts = Counter(random_elements)

total_occurrences = sum(element_counts.values())

percentage_format = "{:.2%}"

for element, count in element_counts.items():
    percentage = count / total_occurrences
    formatted_percentage = percentage_format.format(percentage)
    print(f"{element}:{count}次；{formatted_percentage}")
