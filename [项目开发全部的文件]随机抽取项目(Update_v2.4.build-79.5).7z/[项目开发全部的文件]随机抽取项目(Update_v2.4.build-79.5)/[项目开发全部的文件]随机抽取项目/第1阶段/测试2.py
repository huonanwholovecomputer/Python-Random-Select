import random

def random_sample(text_list, sample_size):
    if sample_size > len(text_list):
        print("Error: Sample size exceeds the length of the text list.")
        return None
    else:
        random_sample = random.sample(text_list, sample_size)
        return random_sample
