import random

students = ["刘奕含","郝晔妮","王慧娟","马跃","窦可冉","马佳雪","袁博","刘杰","张宇航","霍楠","张浩然","张宇轩","杨慧仪","马玲丹","高怡浩","张靖雨","李芊雨","朱佳乐","陈玉","雷航","李媛媛","苗夏雨","马赫","张坤","郝浩然","王文涛","王浩宇","崔知轩","雷淼","米庆","王美丹","马润杰","刘于楠","雷文杰","白宇杰","罗佳庚","贺佳美","王欣瑜","王毅","王浩森","马谢楠","李泽翔", "王森", "崔欣悦", "雷旭阳", "霍俞达","王玙贴","任璠","胡峰","张翔荣"]

while True:
    print("")
    print("-------------------------------------------------------------------------")
    a = input("请输入要抽取的学生数量：")
    if a.isdigit():
        input(a)
        num_a = int(input(a))
        if num_a > len(a):
            print("")
            print("提示：抽取抽取数量超过学生总数！")
            import time
            time.sleep(1)
            print("")
            print("请重新抽取..")
            import time
            time.sleep(1.5)
        else:
            random_students = random.sample(students, num_students)
            print("")
            print("随机本次抽取的学生：", random_students)
            import time
            time.sleep(0.5)
            print("")
            print("等待..")
            import time
            time.sleep(1.5)
    else:
        print("")
        print("请输入整数！")
