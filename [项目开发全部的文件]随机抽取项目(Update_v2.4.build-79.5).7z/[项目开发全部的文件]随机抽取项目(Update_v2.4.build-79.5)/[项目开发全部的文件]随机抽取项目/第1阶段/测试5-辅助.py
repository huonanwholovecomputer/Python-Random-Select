while True:
    a = input("请输入要抽取的学生数量：")
    if a.isdigit():
        print("666")
    else:
        print("777")
