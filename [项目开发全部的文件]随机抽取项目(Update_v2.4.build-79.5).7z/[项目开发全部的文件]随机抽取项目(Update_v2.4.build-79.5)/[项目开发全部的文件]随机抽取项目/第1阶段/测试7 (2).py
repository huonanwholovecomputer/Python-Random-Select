import random
import time

students = ["白宇杰","陈玉","崔欣悦","崔知轩","窦可冉","高怡浩","郝浩然","郝晔妮","贺佳美","胡峰","霍俞达","雷航","雷淼","雷旭阳","李芊雨","李媛媛","李泽翔","刘杰","刘奕含","刘于楠","罗佳庚","马赫","马佳雪","马玲丹","马润杰","马谢楠","马跃","米庆","苗夏雨","任璠","王浩森","王浩宇","王慧娟","王美丹","王森","王文涛","王欣瑜","王玙贴","杨慧仪","袁博","张靖雨","张坤","张翔荣","张宇航","朱佳乐"]

while True:
    print("")
    print("-------------------------------------------------------------------------")
    Y = input("请输入要抽取的学生数量：")
    if Y.isdigit():
        num_students_Y = int(Y)
        if num_students_Y > len(students):
            print("")
            print("提示：抽取抽取数量超过学生总数！")
            time.sleep(1)
            print("")
            print("请重新抽取..")
            time.sleep(1.5)
        else:
            random_students = random.sample(students, num_students_Y)
            print("")
            print("本次随机抽取的学生：", random_students)
            time.sleep(0.5)
            print("")
            print("等待..")
            time.sleep(1.5)
    else:
        print("")
        print("提示：请输入一个正整数！")
