# 随机函数
import random
# 时间函数
import time
# 打字函数
import sys
# 选择函数
import msvcrt
#系统时间函数
import datetime

students =["白宇杰","陈俊昌","陈玉","崔欣悦","崔知轩","窦可冉","冯宇乐","高怡浩","韩怡悦","郝浩然","郝晔妮","贺佳美","胡峰","霍楠","霍俞达","雷航","雷淼","雷文杰","雷旭阳","李芊雨","李媛媛","李泽翔","刘杰","刘奕含","刘于楠","马赫","马佳雪","马玲丹","马润杰","马谢楠","马跃","米庆","苗夏雨","任璠","王浩森","王浩宇","王慧娟","王美丹","王森","王文涛","王欣瑜","王玙贴","杨慧仪","袁博","张靖雨","张坤","张文杰","张翔荣","张宇航","张雨萌","朱佳乐"]

# 直接输入数字进行抽取
while True:                                                                                                                        # while True无限循环
    print("---------------------------------------------")
    # 从记录文件中读取已记录的元素
    with open('记录.txt', 'r') as file:
        recorded_students = set(line.split()[0] for line in file)

    # 移除已记录的元素
    students = [student for student in students if student not in recorded_students]

    # 如果列表为空，则重新初始化
    if not students:
        students = students_English_list    
    A = input("请输入需要抽取的学生个数：")
    if A.isdigit():                                                                                                                # 如果输入非负整数
        num_students_A = int(A)                                                                                                    # 把变量[A]代表的数字转换为整数，并赋值给变量[num_students_A]
        if num_students_A > len(students):   
            print("")                                                                                                              # 如果需要抽取的学生个数超过学生总数
            print("提示：需要抽取的学生个数超过学生总数！")
            time.sleep(0.1)
            print("")
            print("请重新抽取..")
            time.sleep(0.2)
        else:                                                                                                                      # 如果需要抽取的学生个数≤学生总数
            B = 0                                                                                                                  # 将0赋值给变量[B]
            s_students = []                                                                                                        # 创建一个列表，命名为[s_students]
            while B < num_students_A:                                                                                              # 循环，直到条件[B < num_students_A]不满足则退出循环
                B += 1                                                                                                             # 将变量[B]的值+1（即B = B+1）
                s_c = {student: 0 for student in students}
                C = random.randint(10000, 100000)                                                                                  # 创建一个变量[C]，值为10000到100000的随机数
                D = 0                                                                                                              # 将0赋值给变量[D]
                while D < C:                                                                                                       # 循环，直到条件[D < C]不满足则退出循环
                    r_student = random.choice(students)                                                                            # 随机抽取一个学生
                    s_c[r_student] += 1                                                                                            # 增加该学生被选中的次数
                    D += 1                                                                                                         # 让变量D加1，用于控制while循环
                s_s_c = sorted(s_c.items(), key=lambda x: -x[1])                                                                   # 对字典[s_c]中的值从大到小排序
                X = random.randint(1, len(students))                                                                               # 创建一个变量[X]，值为1到[len(students)]的随机数
                s_student = s_s_c[X - 1][0]                                                                                        # 选择排名为第[X]名的学生
                if s_student in s_students:                                                                                        # 如果本次循环选中的学生存在于最终的选中学生名单中
                    num_students_A += 1                                                                                            # 将抽取次数加1
                else:                                                                                                              # 如果本次循环选中的学生不存在于最终的选中学生名单中
                    s_students.append(s_student)                                                                                   # 将本次循环选中的学生加入最终选中的学生名单中
                    now = datetime.datetime.now()                                                                                  # 获取当前日期和时间
                    # 将元素添加到记录集合中: recorded_students.add(student)
                    # 将元素写入记录文件
                    with open('记录.txt', 'a') as file:
                        file.write(s_student + ' ' + now.strftime('%Y-%m-%d %H:%M:%S') + '\n')
            print("")
            print("抽取结果：", s_students)                                                                                        # 打印最终选中的学生名单
            time.sleep(0.5)

