import random
import datetime

# 定义列表
my_list = ['a', 'b', 'c', 'd', 'e']

# 从记录文件中读取已记录的元素
with open('记录.txt', 'r') as file:
    recorded_elements = set(line.split()[0] for line in file)

# 移除已记录的元素
my_list = [item for item in my_list if item not in recorded_elements]

# 如果列表为空，则重新初始化
if not my_list:
    my_list = ['a', 'b', 'c', 'd', 'e']

# 获取当前日期和时间
now = datetime.datetime.now()

# 从列表中随机抽取一个元素
element = random.choice(my_list)

# 将元素添加到记录集合中
recorded_elements.add(element)

# 将元素写入记录文件
with open('记录.txt', 'a') as file:
    file.write(element + ' ' + now.strftime('%Y-%m-%d %H:%M:%S') + '\n')

print("已记录的元素：", recorded_elements)
print("剩余的元素：", my_list)
