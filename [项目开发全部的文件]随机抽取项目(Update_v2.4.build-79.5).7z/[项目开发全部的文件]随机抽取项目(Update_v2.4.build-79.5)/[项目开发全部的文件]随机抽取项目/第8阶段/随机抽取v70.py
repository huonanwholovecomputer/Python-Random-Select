# 随机函数
import random
# 时间函数
import time
# 打字函数
import sys
# 选择函数
import msvcrt

# 英语专用名单
students_1 = ["白宇杰","陈俊昌","陈玉","崔欣悦","崔知轩","窦可冉","高怡浩","韩敬哲","韩怡悦","郝浩然","郝晔妮","贺佳美","胡峰","霍楠","霍俞达","雷航","雷淼","雷旭阳","李芊雨","李媛媛","李泽翔","刘杰","刘奕含","刘于楠","马赫","马佳雪","马玲丹","马润杰","马谢楠","马跃","米庆","苗夏雨","任璠","王浩森","王浩宇","王慧娟","王美丹","王森","王文涛","王欣瑜","王玙贴","杨慧仪","袁博","张靖雨","张坤","张翔荣","张宇航","张雨萌","朱佳乐"]
# 所有学生名单
students_2 = ["白宇杰","陈俊昌","陈玉","崔欣悦","崔知轩","窦可冉","冯宇乐","高怡浩","韩敬哲","韩怡悦","郝浩然","郝晔妮","贺佳美","胡峰","霍楠","霍俞达","雷航","雷淼","雷文杰","雷旭阳","李芊雨","李媛媛","李泽翔","刘杰","刘奕含","刘于楠","马赫","马佳雪","马玲丹","马润杰","马谢楠","马跃","米庆","苗夏雨","任璠","王浩森","王浩宇","王慧娟","王美丹","王森","王文涛","王欣瑜","王玙贴","杨慧仪","袁博","张靖雨","张坤","张文杰","张翔荣","张宇航","张雨萌","朱佳乐"]
# 输出“随机抽取，启动！”
s = "随机抽取，启动！"
for char in s:
    print(char, end="")
    sys.stdout.flush()
    if char in ["，", "！"]:
        time.sleep(0.5)
    else:
        time.sleep(0.02)
# 选择学生名单
def get_choice():
    global students
    while True:# while True无限循环
        print("")
        print("---------------------------------------------")
        print("请选择学生名单：")
        print("")
        print("【1】 英语课专用（无日语学生）")
        print("")
        print("【2】 常规（全体学生）")
        print("")
        print("【3】 帮助（也可输入“？”、“?”）")
        print("---------------------------------------------")
        k = msvcrt.getch()
        if k == b"1":
            s = "已选择【1】，进入：英语课专用的随机抽取(无日语学生)"
            for char in s:
                print(char, end="")
                sys.stdout.flush()
                time.sleep(0.01)
            students = students_1
            print("")
            print("")
            print("本名单总人数：", end="")
            print(len(students))
            time.sleep(0.2)
            break
        elif k == b"2":
            s = "已选择【2】，进入：常规随机抽取(全体学生)"
            for char in s:
                print(char, end="")
                sys.stdout.flush()
                time.sleep(0.01)
            students = students_2
            print("")
            print("")
            print("本名单总人数：", end="")
            print(len(students))
            time.sleep(0.2)
            break
        elif k == b"3" or k == b"?" or k == "？":
            print("")
            print("---------------------------------------------")
            s = "已选择【3】，帮助：输入1或者2，进入指定的抽取模式"
            for char in s:
                print(char, end="")
                sys.stdout.flush()
                time.sleep(0.01)
            print("")
            time.sleep(0.2)
        else:
            print("")
            print("无效选择！")
            time.sleep(0.1)
            print("")
            print("请重新选择！")
            time.sleep(0.1)
get_choice()
while True:# while True无限循环
    print("---------------------------------------------")
    A = input("需要抽取的学生个数：")
    if A.isdigit():# 如果输入非负整数
        num_students_A = int(A)# 把变量[A]代表的数字转换位为浮点数，并赋值给变量[num_students_A]
        if num_students_A > len(students):# 如果需要抽取的学生个数超过学生总数
            print("提示：需要抽取的学生个数超过学生总数！")
            time.sleep(0.1)
            print("")
            print("请重新抽取..")
            time.sleep(0.2)
        else:# 如果需要抽取的学生个数≤学生总数
          B = 0# 将0赋值给变量[B]
          s_students = []# 创建一个集合，命名为[s_students]
          while B < num_students_A:# while循环，当条件[B < num_students_A]不满足则退出循环
              B += 1# 将变量[B]的值+1（即B = B+1）
              s_c = {student: 0 for student in students}
              C = random.randint(10000, 100000)# 创建一个变量[C]，值为10000到100000的随机数
              C = int(C)# 将变量[C]代表的数字转换为浮点数，并赋值给变量[C]
              D = 0#将0赋值给变量[D]
              while D < C:# while循环，当条件[D < C]不满足则退出循环
                  r_student = random.choice(students)# 随机抽取一个集合[students]中的一个学生，赋值给[r_students]
                  s_c[r_student] += 1# 将[r_student]赋值给s_c
                  D += 1# 让变量D加1，用于控制while循环
              s_s_c = sorted(s_c.items(), k=lambda x: -x[1])# 对集合[s_c]中的值从大到小排序
              X = random.randint(1, len(students))# 创建一个变量[]
              s_student = s_s_c[X - 1]# 选择排名为第[X]名的学生
              if s_student in s_students:# 如果本次循环选中的学生存在于最终的选中学生名单中
                  num_students_A += 1# 将抽取次数加1
              else:# 如果本次循环选中的学生不存在于最终的选中学生名单中
                  s_students.append(s_student)# 将本次循环选中的学生加入最终选中的学生名单中
          print("")
          print("抽取结果：", s_students)#Print最终选中的学生名单
          time.sleep(0.5)
# 如果输入"测试程序"，进入测试程序模式选择
    elif A == "测试程序" or A == "cscx":
        def get_choice():
            while True:# while True无限循环
                print("---------------------------------------------")
                print("请选择运行选项：")
                time.sleep(0.2)
                print("")
                print("【1】 测试程序")
                print("")
                print("【2】 帮助（也可输入“？”、“?”）")
                print("---------------------------------------------")
                k = msvcrt.getch()
                if k == b"1":  # 注意这里的比较值应为字节串
                    print( "已选择【1】，进入：测试程序")
                    time.sleep(0.2)
                    # 测试程序
                    while True:# while True无限循环
                        # 输入非负整数
                        print("---------------------------------------------")
                        b = input("需要抽取的学生个数：")
                        if b.isdigit():
                            num_students_b = int(b)
                            if num_students_b > len(students):
                                print("提示：需要抽取的学生个数超过学生总数！")
                                time.sleep(0.1)
                                print("")
                                print("请重新抽取..")
                                time.sleep(0.2)
                            else:
                                print("")
                                c = 0
                                e = 1
                                b = int(b)
                                selection_students = []
                                while c < b:
                                    c += 1
                                    e += 1
                                    selection_counts = {student: 0 for student in students}
                                    a = random.randint(10000, 100000)
                                    time.sleep(0.2)
                                    print("本次随机抽取的的随机抽取次数：", end="")
                                    print(a, end="")
                                    print("次")
                                    print("")
                                    time.sleep(0.5)
                                    num_students = int(a)
                                    counter = 0
                                    max_iterations = num_students
                                    while counter < max_iterations:
                                        random_student = random.choice(students)
                                        selection_counts[random_student] += 1
                                        counter += 1
                                    print("")
                                    total_count = sum(selection_counts.values())
                                    sorted_selection_counts = sorted(selection_counts.items(), k=lambda x: -x[1])
                                    position = 1
                                    for student, count in sorted_selection_counts:
                                        percentage = count / total_count * 100
                                        print("第",position,"名",end="：")
                                        print(f"{student}: 被抽取次数：{count} 次 ；频率：({percentage:.3f}%)")
                                        position +=1
                                        # 生成一个介于1到学生总数之间的随机数x
                                        print("")
                                    x = random.randint(1, len(students))
                                    print("本次选择的学生是排名为第",x,"名的学生")
                                    print("")
                                    # 获取排名为x的学生
                                    max_student, max_count = sorted_selection_counts[x - 1]
                                    print("本次选中的学生：", end="")
                                    print(f"【{max_student}】；次数：{max_count} 次；频率：{percentage:.3f}%")
                                    print("")
                                    print("第", c, "次抽取结束！")
                                    time.sleep(0.5)
                                    print("")
                                    print("正在决定是否开启第", e,"次抽取...")
                                    time.sleep(1)
                                    print("")
                                    if max_student in selection_students:
                                        b += 1
                                        print("")
                                        s = "抽取过程中出现重复的学生，准备重新抽取"
                                        for char in s:
                                            print(char, end="")
                                            sys.stdout.flush()
                                            time.sleep(0.05)
                                        time.sleep(1)
                                    else:
                                        selection_students.append(max_student)
                                    if selection_students.count(max_student) > 1:
                                        selection_students.remove(max_student)
                                print("")
                                print("最终的抽取结果：",selection_students)
                                print("")
                elif k == b"2" or d == "?"or d == "？":
                    print("")
                    print("帮助：")
                    print("---------------------------------------------")
                    s = "“测试程序”用于显示本程序的详细运行方式。"
                    for char in s:
                        print(char, end="")
                        sys.stdout.flush()
                        time.sleep(0.01)
                    time.sleep(0.2)
                    print("")
                else:
                    print("---------------------------------------------")
                    print("无效选择！")
                    time.sleep(0.1)
                    print("")
                    print("请重新选择！")
                    time.sleep(0.1)
        get_choice()
    # 如果输入"?",显示程序运行机制以及提示。
    elif d == "?" or d == "？":
        print("")
        s = "本程序的运行机制是，随机抽取一个学生，抽取一定次数（抽取次数是1万到十万的随机数）后，抽取完成之后，统计每个学生的被抽取次数、被抽取率（本次被抽取的次数与总抽取次数的百分比），选择被抽取次数排名为变量[X]的名的学生作为选中的学生，并计入集合[selection_students]。输入需要的学生数量，就循环多少次（在[selection_students]集合中计入多少个学生。）"
        for char in s:
            print(char, end="")
            sys.stdout.flush()
            if char in ["，", "。", "（", "）"]:
                time.sleep(0.1)
            else:
                time.sleep(0.01)
        time.sleep(1)
        print("")
        print("")
        s = "本程序为了防止一些错误输入而导致的程序崩溃，还加入了一些检查功能"
        for char in s:
            print(char, end="")
            sys.stdout.flush()
            if char in ["，", "。"]:
                time.sleep(0.1)
            else:
                time.sleep(0.01)
        time.sleep(1)
        print("")
        print("")
        s = "比如："
        for char in s:
            print(char, end="")
            sys.stdout.flush()
            if char in ["，", "："]:
                time.sleep(0.1)
            else:
                time.sleep(0.01)
        time.sleep(1)
        print("")
        print("")
        s = "1.在抽取学生时，输入了数字之外的其他字符或文字，从而导致的程序崩溃（因为进入学生抽取运算的值只能时数字），我加入了[if d.isdigit()]用于检测输入的值是否是数字"
        for char in s:
            print(char, end="")
            sys.stdout.flush()
            if char in ["，", "。", "（", "）","[","]"]:
                time.sleep(0.1)
            else:
                time.sleep(0.01)
        time.sleep(1)
        print("")
        print("")
        s = "2.在抽取学生时，输入的数字如果大于学生总人数，则会导致程序一直运行下去，于是我加入了[if num_students_A > len(students)]用于检测输入的值是否大于学生名单总人数"
        for char in s:
            print(char, end="")
            sys.stdout.flush()
            if char in ["，", "。", "（", "）","[","]"]:
                time.sleep(0.1)
            else:
                time.sleep(0.01)
        time.sleep(1)
        print("")
        s = "3.在抽取学生时，"
    # 如果输入的项目不合法，则：
    else:
        print("---------------------------------------------")
        print("*请输入有效命令！")
        time.sleep(0.1)
        print("1.可输入数字，抽取指定的学生人数")
        time.sleep(0.1)
        print("2.可输入“？”或“?”查看当前程序位置的帮助")
        time.sleep(0.1)
        print("3.可输入“测试程序”或“cscx”显示程序在进行随机抽取时的详细运行过程")
        time.sleep(0.1)
        