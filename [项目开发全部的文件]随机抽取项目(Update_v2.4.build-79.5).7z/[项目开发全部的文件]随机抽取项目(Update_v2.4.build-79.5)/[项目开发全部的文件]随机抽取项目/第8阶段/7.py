# 随机函数
import random
# 时间函数
import time
# 打字函数
import sys
# 选择函数
import msvcrt

# 英语专用名单
students = ["白宇杰","陈俊昌","陈玉","崔欣悦","崔知轩","窦可冉","高怡浩","韩敬哲","韩怡悦","郝浩然","郝晔妮","贺佳美","胡峰","霍楠","霍俞达","雷航","雷淼","雷旭阳","李芊雨","李媛媛","李泽翔","刘杰","刘奕含","刘于楠","马赫","马佳雪","马玲丹","马润杰","马谢楠","马跃","米庆","苗夏雨","任璠","王浩森","王浩宇","王慧娟","王美丹","王森","王文涛","王欣瑜","王玙贴","杨慧仪","袁博","张靖雨","张坤","张翔荣","张宇航","张雨萌","朱佳乐"]

while True:
    while True:
        def get_choice():                                                                                                          # 函数 get_choice() 的目的是提供一个选择菜单，并等待用户选择他们想要进行的操作。
            while True:                                                                                                            # while True无限循环
                print("---------------------------------------------")
                print("请选择运行选项：")
                time.sleep(0.2)
                print("")
                print("【1】 测试程序")
                print("")
                print("【2】 帮助（也可输入“？”、“?”）")
                print("---------------------------------------------")
                k = msvcrt.getch()
                if k == b"1":  # 这里的比较值为字节串
                    print( "已选择【1】，进入：测试程序")
                    time.sleep(0.2)
                    # 测试程序
                    while True:
                        print("---------------------------------------------")
                        num_students_b = input("需要抽取的学生个数：")
                        if num_students_b.isdigit():                                                                               # 如果输入非负整数
                            num_students_b = int(num_students_b)
                            if num_students_b > len(students):
                                print("提示：需要抽取的学生个数超过学生总数！")                                                    # 打印文字“提示：需要抽取的学生个数超过学生总数！”
                                time.sleep(0.1)                                                                                    # 暂停程序0.1秒
                                print("")
                                print("请重新抽取...")                                                                             # 打印文字“请重新抽取...”                                                                       # 打印文字“请重新抽取...”
                                time.sleep(0.2)                                                                                    # 暂停程序0.1秒
                            else:                                                                                                  # 如果输入的学生个数不超过学生总数，则执行以下代码
                                selection_students = []                                                                            # 创建一个集合[selection_students]，用于计入被选中的学生
                                cycle_count = 0                                                                                    # 初始化计数器[cycle_count]为0
                                while cycle_count < num_students_b:                                                                # 循环次数[cycle_count]为用户输入的学生个数[num_students_b]
                                    cycle_count += 1                                                                               # 每次循环计数器[cycle_count]增加1
                                    show_count = 1                                                                                 # 初始化计数器[show_count]为1
                                    selection_counts = {student: 0 for student in students}                                        # 创建一个字典，每个学生的初始抽取次数为0，用于记录每个学生的被抽取次数
                                    a = random.randint(10000, 100000)                                                              # 生成一个10000到100000之间的随机数
                                    time.sleep(0.2)                                                                                # 暂停程序0.2秒
                                    print("本次随机抽取的抽取次数：", end="")                                                      # 打印文字：本次随机抽取的抽取次数
                                    print(a, end="")                                                                               # 打印变量a
                                    print("次")                                                                                    # 打印文字：次
                                    time.sleep(0.5)                                                                                # 暂停程序0.5秒
                                    counter = 0                                                                                    # 初始化计数器[counter]为0
                                    while counter < a:                                                                             # 循环，直到条件[counter < a]不满足则退出循环【实现的关键功能：一共抽取变量[a]次】
                                        random_student = random.choice(students)                                                   # 使用[random.choice]函数从学生列表[students]中随机选择一个学生，命名为[random_student]
                                        selection_counts[random_student] += 1                                                      # 在字典[selection_counts]中增加被选中的学生[random_student]的被抽取次数
                                        counter += 1                                                                               # 每次循环，变量[counter]增加1，用于控制总抽取次数
                                    total_count = sum(selection_counts.values())                                                   # 计算[selection_counts]字典中所有值的总和，即所有学生被抽取的总次数
                                    sorted_selection_counts = sorted(selection_counts.items(), key= lambda x: -x[1])               # 将[selection_counts]进行从大到小排序，x[1]指的是字典项的值（即学生的被抽取次数）
                                    position = 1                                                                                   # 初始化变量[position]，用于表示学生的排名
                                    for student, count in sorted_selection_counts:                                                 # 遍历列表[sorted_selection_counts]，for循环的每次迭代都会从列表[sorted_selection_counts]中取出一个元组，并将其分解为两个变量：[student]和[count]；变量[student]接收元组的第一个元素（学生的名字），而变量[count]接收元组的第二个元素（该学生被抽取的次数）。
                                        percentage = count / total_count * 100                                                     # 计算每个学生被抽取的频率百分比
                                        print("第",position,"名",end="：")                                                         # 打印文字“第”和变量[position]和标点符号“：”，并使用[end="："]告诉print函数在输出结束后不要添加换行符[\n]，使print函数执行完毕后，下一个输出的内容将会紧接着冒号后面出现，而不是在新的一行。
                                        print(f"{student}: 被抽取次数：{count} 次 ；频率：({percentage:.3f}%)")                    # 打印学生的姓名、被抽取次数和频率百分比，其中频率保留三位小数；使用[f(f-string格式化字符串字面量)]格式化字符串，并中在字符串中插入变量{student}{count}{percentage:.3f}%)
                                        position +=1                                                                               # 每次循环结束，变量[position]增加1，表示下一个学生的排名sequence = random.randint(1, len(students))# # 创建一个变量[sequence]，值为1到[len(students)]的随机数
                                    sequence = random.randint(1, len(students))                                                    # 生成一个1到学生列表总数之间的随机数
                                    selection_student, selection_student_count = sorted_selection_counts[sequence - 1]             # 从包含学生选择情况的列表[sorted_selection_counts]中选择第[sequence]个元组，并分解为两个值，分别赋值给[selection_student]和[selection_student_count]
                                    print("")
                                    print("本次选择的学生是：排名为第", sequence ,"名的学生：", end="")                            # 打印文字“本次选择的学生是排名为第”和变量[sequence]和文字“名的学生”
                                    print(f"{selection_student}；次数：{selection_student_count} 次；频率：{percentage:.3f}%")
                                    time.sleep(0.5)
                                    show_count += 1
                                    print("")
                                    print("正在决定是否开启第", show_count ,"次抽取...")                                           # 打印文字“正在决定是否开启第”和变量[show_count]和文字“次抽取...”
                                    time.sleep(1)
                                    print("")
                                    if selection_student in selection_students:                                                    # 如果本次循环选中的学生已经存在[selection_students]中
                                        b += 1
                                        print("")
                                        s = "抽取过程中出现重复的学生，准备重新抽取"
                                        for char in s:
                                            print(char, end="")
                                            sys.stdout.flush()
                                            time.sleep(0.05)
                                        time.sleep(1)
                                    else:
                                        selection_students.append(selection_student)# 将本次选中的学生应用（加入）
                                    if selection_students.count(selection_student) > 1:
                                        selection_students.remove(selection_student)
                                print("最终的抽取结果：【",selection_students,"】")
                        elif num_students_b == "?" or num_students_b =="？":
                            print("")
                            print("帮助：")
                            s = "“测试程序”用于显示本程序的详细运行方式。"
                            for char in s:
                                print(char, end="")
                                sys.stdout.flush()
                                time.sleep(0.01)
                            time.sleep(1)
                            print("")
                            print("---------------------------------------------")
                            s = "本程序的运行机制是，随机抽取一个学生，抽取一定次数（抽取次数是1万到十万的随机数）后，抽取完成之后，统计每个学生的被抽取次数、被抽取率（本次被抽取的次数与总抽取次数的百分比），选择被抽取次数排名为变量[X]的名的学生作为选中的学生，并计入集合[selection_students]。输入需要的学生数量，就循环多少次（在[selection_students]集合中计入多少个学生。）"
                            for char in s:
                                print(char, end="")
                                sys.stdout.flush()
                                if char in ["，", "。", "（", "）"]:
                                    time.sleep(0.1)
                                else:
                                    time.sleep(0.01)
                            time.sleep(1)
                            print("")
                        else:
                            print("")
                            print("无效输入！")
                            
                elif k == b"2" or d == "?"or d == "？":
                    print("")
                    print("帮助：")
                    print("---------------------------------------------")
                    s = "“测试程序”用于显示本程序的详细运行方式。"
                    for char in s:
                        print(char, end="")
                        sys.stdout.flush()
                        time.sleep(0.01)
                    time.sleep(0.2)
                    print("")
                else:
                    print("---------------------------------------------")
                    print("无效选择！")
                    time.sleep(0.1)
                    print("")
                    print("请重新选择！")
                    time.sleep(0.1)
        get_choice()
