while True:
    while True:
        while True:
            students_English_list = ["白宇杰","陈俊昌","陈玉","崔欣悦","崔知轩","窦可冉","高怡浩","韩怡悦","郝浩然","郝晔妮","贺佳美","胡峰","霍楠","霍俞达","雷航","雷淼","雷旭阳","李芊雨","李媛媛","李泽翔","刘杰","刘奕含","刘于楠","马赫","马佳雪","马玲丹","马润杰","马谢楠","马跃","米庆","苗夏雨","任璠","王浩森","王浩宇","王慧娟","王美丹","王森","王文涛","王欣瑜","王玙贴","杨慧仪","袁博","张靖雨","张坤","张翔荣","张宇航","张雨萌","朱佳乐"]
            check_students_English_list = ["陈俊昌","陈玉","崔欣悦","崔知轩","窦可冉","高怡浩","韩怡悦","郝浩然","郝晔妮","贺佳美","胡峰","霍楠","霍俞达","雷航","雷淼","雷旭阳","李芊雨","李媛媛","李泽翔","刘杰","刘奕含","刘于楠","马赫","马佳雪","马玲丹","马润杰","马谢楠","马跃","米庆","苗夏雨","任璠","王浩森","王浩宇","王慧娟","王美丹","王森","王文涛","王欣瑜","王玙贴","杨慧仪","袁博","张靖雨","张坤","张翔荣","张宇航","张雨萌","朱佳乐"]    
            check_students_English_set = set(check_students_English_list)
            students_English_set = set(students_English_list)
            # 找出列表[pstudents_English_list]相比列表[check_students_English_list]缺少的元素
            missing_students = [student for student in check_students_English_list if student not in students_English_list]
            # 找出列表[pstudents_English_list]相比列表[check_students_English_list]多余的元素
            extra_students = [student for student in students_English_list if student not in check_students_English_list]
            print("")
            print("---------------------------------------------")
            if len(students_English_set) == len(students_English_list):
                print("[英语科专用的随机抽取名单]  中没有重复的学生")
            time.sleep(0.25)
            print("")
            if len(check_students_English_set) == len(check_students_English_list):
                print("[英语科专用的核对名单]      中没有重复的学生")
            time.sleep(0.25)
            print("")
            print("[英语科专用的随机抽取名单]  总人数：",len(students_English_list))
            time.sleep(0.25)
            print("")
            print("[英语科专用的核对名单]      总人数：",len(check_students_English_list))
            time.sleep(0.5)
            if not missing_students and not extra_students:
                time.sleep(0.5)
                print("")
                print("[英语科专用的随机抽取名单]与[英语科专用的核对名单]一致！")
            if missing_students:
                print("")
                print("")
                print("[英语科专用的随机抽取名单]与[英语科专用的核对名单]不一致！")
                print("")
                print("名单中缺失学生：",missing_students)
            if extra_students:
                print("")
                print("")
                print("[英语科专用的随机抽取名单]与[英语科专用的核对名单]不一致！")
                print("")
                print("名单中多余学生：",extra_students)
