import random

students = ["刘奕含","郝晔妮","王慧娟","马跃","窦可冉","马佳雪","袁博","刘杰","张宇航","霍楠","张浩然","杨慧仪","马玲丹","高怡浩","张靖雨","李芊雨","朱佳乐","陈玉","雷航","李媛媛","苗夏雨","马赫","张坤","郝浩然","王文涛","王浩宇","崔知轩","雷淼","米庆","王美丹","马润杰","刘于楠","雷文杰","白宇杰","罗佳庚","贺佳美","王欣瑜","王毅","王浩森","马谢楠","李泽翔", "王森", "崔欣悦", "雷旭阳", "霍俞达","王玙贴","任璠","胡峰","张翔荣"]
count = 1000000
results = {student: 0 for student in students}

for _ in range(count):
    if len(students) > 0:
        random_student = random.choice(students)
        results[random_student] += 1

sorted_results = sorted(results.items(), key=lambda x: x[1], reverse=True)

for student, num_times in sorted_results:
    percentage = (num_times / count) * 100
    print(f"{student}: {percentage:.2f}%")
