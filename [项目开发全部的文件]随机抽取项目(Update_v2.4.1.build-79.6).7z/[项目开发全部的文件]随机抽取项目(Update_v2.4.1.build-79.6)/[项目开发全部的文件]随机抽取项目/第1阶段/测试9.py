import random

students = ["學生1", "學生2", "學生3", "學生4", "學生5", "學生6"]

num_students_Y = int(input("請輸入要抽取的學生數量："))

def extract_students(num_students):
    student_counts = {student: 0 for student in students}
    total_draws = 0

    while True:
        num_draws = random.randint(10000, 100000)
        for _ in range(num_draws):
            chosen_student = random.choice(students)
            student_counts[chosen_student] += 1
            total_draws += 1

        sorted_students = sorted(student_counts.items(), key=lambda x: x[1], reverse=True)
        if sorted_students[0][1] >= num_students:
            print(f"恭喜！第一位被抽中的學生是：【{sorted_students[0][0]}】")
            return

while True:
    extract_students(num_students_Y)
    selected_student_count = max(extract_students(num_students_Y)[0][1] for _ in range(5))
    if selected_student_count >= num_students_Y:
        break
