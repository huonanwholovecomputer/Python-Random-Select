import random

elements = ['a', 'b', 'c', 'd', 'e']
random_element = random.choice(elements)
print(random_element)
