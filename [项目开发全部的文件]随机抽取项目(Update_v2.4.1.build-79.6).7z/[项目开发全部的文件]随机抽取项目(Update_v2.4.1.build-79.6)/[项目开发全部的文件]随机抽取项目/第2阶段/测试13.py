import random

elements = ['a', 'b', 'c', 'd', 'e']

n = random.randint(1, 10)  # 隨機生成一個介於1和10之間的數字

for _ in range(n):
    random_element = random.choice(elements)
    print(random_element)
