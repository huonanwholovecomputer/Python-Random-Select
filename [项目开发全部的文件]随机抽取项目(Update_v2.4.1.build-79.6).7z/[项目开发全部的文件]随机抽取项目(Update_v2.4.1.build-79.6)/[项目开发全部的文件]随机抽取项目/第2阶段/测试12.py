import random

elements = ['a', 'b', 'c', 'd', 'e']

for _ in range(2):
    random_element = random.choice(elements)
    print(random_element)
