import keyboard
import time

def simulate_keyboard_events():
    time.sleep(2)
    while True:
        # 模拟按下键盘上的“6”
        keyboard.press_and_release('6')
        time.sleep(0.01)  # 等待一小段时间

        # 模拟按下Enter键
        keyboard.press_and_release('enter')
        time.sleep(0.01)

        # 模拟按下键盘上的“c”
        keyboard.press_and_release('c')
        time.sleep(0.01)

        # 模拟按下Enter键
        keyboard.press_and_release('enter')

if __name__ == "__main__":
    simulate_keyboard_events()
