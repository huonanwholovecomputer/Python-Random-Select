import random
from collections import Counter
from openpyxl import Workbook

# 创建一个工作簿
wb = Workbook()

# 选择第一个工作表
ws = wb.active

# 你的列表数据
data = ["白宇杰","陈俊昌","陈玉","崔欣悦","崔知轩","窦可冉","高怡浩","韩怡悦","郝浩然","郝晔妮","贺佳美","胡峰","霍楠","霍俞达","雷航","雷淼","雷旭阳","李芊雨","李媛媛","李泽翔","刘杰","刘奕含","刘于楠","马赫","马佳雪","马玲丹","马润杰","马谢楠","马跃","米庆","苗夏雨","任璠","王浩森","王浩宇","王慧娟","王美丹","王森","王文涛","王欣瑜","王玙贴","杨慧仪","袁博","张靖雨","张坤","张翔荣","张宇航","张雨萌","朱佳乐"]

# 随机抽取一个元素
selected_item = random.choice(data)

# 统计元素被抽取的次数
counter = Counter()
counter[selected_item] += 1

# 将数据写入第一列和第二列
for index, value in enumerate(data, start=1):
    ws.cell(row=index, column=1, value=value)
    ws.cell(row=index, column=2, value=counter[value])

# 保存工作簿
wb.save("output.xlsx")
