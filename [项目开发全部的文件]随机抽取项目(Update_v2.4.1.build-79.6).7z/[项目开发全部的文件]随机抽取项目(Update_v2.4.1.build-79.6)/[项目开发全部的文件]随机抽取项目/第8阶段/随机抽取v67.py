import random
import time

# 英语专用名单
students = ["张三", "李四"]  # 示例学生名单，实际应用中可能需要更长的名单

while True:
    print("")
    d = input("需要抽取的学生个数：")
    print("")
    
    # 如果输入非负整数
    if d.isdigit() and int(d) > 0:
        num_students_d = int(d)
        if num_students_d > len(students):
            print("提示：需要抽取的学生个数超过学生总数！")
            time.sleep(0.5)
            print("")
            print("请重新抽取..")
            time.sleep(1)
        else:
            # 初始化学生选择次数字典
            selection_counts = {student: 0 for student in students}
            
            # 进行随机选择
            for _ in range(num_students_d):
                random_student = random.choice(students)
                selection_counts[random_student] += 1
            
            # 按选择次数排序
            sorted_selection_counts = sorted(selection_counts.items(), key=lambda x: x[1], reverse=True)
            
            # 生成一个介于1到学生总数之间的随机数x
            x = random.randint(1, len(students))
            
            # 获取排名为x的学生
            if len(sorted_selection_counts) >= x:
                xth_student, xth_count = sorted_selection_counts[x - 1]
                print(f"被选中次数排名为第{x}名的学生是：{xth_student}, 被选中次数为：{xth_count}")
            else:
                print("学生人数不足以确定第x名的选中次数。")
            
            time.sleep(1)
    else:
        print("请输入一个正整数。")