import random
import time

students = ["学生1","学生2","学生3","学生4","学生5","学生6","学生7","学生8","学生9"]
c = 0

while True:
    c += 1
    b = input("請輸入需要抽取的學生人數：")

    if b.isdigit():
        if c <= int(b):
            selection_counts = {student: 0 for student in students}
            print("")            
            a = random.randint(1000, 10000)
            print("本次隨機的抽取次數：", end="")
            print(a)
            num_students = int(a)
            counter = 0
            max_iterations = num_students

            while counter < max_iterations:
                random_student = random.choice(students)
                selection_counts[random_student] += 1
                counter += 1
            
            print("")
            print("抽取結束")
            print("學生抽取次數統計：")
            total_count = sum(selection_counts.values())

            for student, count in selection_counts.items():
                percentage = count / total_count * 100
                print(f"{student}: {count} 次 ({percentage:.2f}%)")
        else:
            break
    else:
        print("请输入一个正整数！")
