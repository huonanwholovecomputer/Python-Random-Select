import random
b = int(input("请输入一个数字："))
c = 0
d = 0
while c < b:
    c += 1
    d += 1
    students = ["学生1","学生2","学生3","学生4","学生5","学生6","学生7","学生8","学生9"]
    selection_counts = {student: 0 for student in students}
    a = random.randint(1000, 10000)
    num_students = int(a)
    counter = 0
    max_iterations = num_students
    while counter < max_iterations:
        random_student = random.choice(students)
        selection_counts[random_student] += 1
        counter += 1
    print("")
    total_count = sum(selection_counts.values())
    sorted_selection_counts = sorted(selection_counts.items(), key=lambda x: x[1])
    for student, count in sorted_selection_counts:
        percentage = count / total_count * 100

    max_student_d, max_count = sorted_selection_counts[-1]
    print("本次被抽取次数最高的学生：", end="")
    print(f"【{max_student_d}】；次数：{max_count} 次；占总抽取次数百分比：{percentage:.3f}%")
    print("第",d,"次循环")
