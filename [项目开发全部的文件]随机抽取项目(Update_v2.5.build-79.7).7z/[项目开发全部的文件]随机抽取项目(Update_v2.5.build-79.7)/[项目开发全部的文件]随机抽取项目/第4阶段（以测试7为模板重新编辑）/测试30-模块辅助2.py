import random
import time
counter = 0  # 計數器變量，用於記錄循環次數
max_iterations = 5  # 最大循環次數
while counter < max_iterations:
    random_students = random.sample(students, num_students_n)
    print("")
    print("本次隨機抽取的學生：", random_students)
    time.sleep(0.5)
    print("")
    print("等待..")
    time.sleep(1)
    counter += 1  # 每次循環結束後，計數器加1
print("循環已停止")  # 循環結束後的輸出信息
