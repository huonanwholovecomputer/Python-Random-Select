m=0
m=m+1
print(m)
