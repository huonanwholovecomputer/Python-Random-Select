import curses
import time

def print_typewriter(text):
    stdscr = curses.initscr()
    curses.curs_set(0)
    
    for char in text:
        stdscr.addch(char)
        stdscr.refresh()
        time.sleep(0.1)
    
    curses.endwin()

sentence = "Hello, world! This is typewriter effect."

print_typewriter(sentence)
