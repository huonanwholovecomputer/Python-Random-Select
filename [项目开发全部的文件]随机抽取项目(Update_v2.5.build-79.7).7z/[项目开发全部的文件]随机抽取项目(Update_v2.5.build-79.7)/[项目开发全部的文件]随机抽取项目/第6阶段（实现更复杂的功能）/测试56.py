import random
import time
import sys
import msvcrt

students_1 = ["白宇杰","陈玉","崔欣悦","崔知轩","窦可冉","高怡浩","郝浩然","郝晔妮","贺佳美","胡峰","霍俞达","雷航","雷淼","雷旭阳","李芊雨","李媛媛","李泽翔","刘杰","刘奕含","刘于楠","罗佳庚","马赫","马佳雪","马玲丹","马润杰","马谢楠","马跃","米庆","苗夏雨","任璠","王浩森","王浩宇","王慧娟","王美丹","王森","王文涛","王欣瑜","王玙贴","杨慧仪","袁博","张靖雨","张坤","张翔荣","张宇航","朱佳乐"]
students_2 = ["白宇杰","陈玉","崔欣悦","崔知轩","窦可冉","冯宇乐","高怡浩","郝浩然","郝晔妮","贺佳美","胡峰","霍楠","霍俞达","雷航","雷淼","雷文杰","雷旭阳","李芊雨","李媛媛","李泽翔","刘杰","刘奕含","刘于楠","罗佳庚","马赫","马佳雪","马玲丹","马润杰","马谢楠","马跃","米庆","苗夏雨","任璠","王浩森","王浩宇","王慧娟","王美丹","王森","王文涛","王欣瑜","王玙贴","杨慧仪","袁博","张靖雨","张坤","张文杰","张翔荣","张宇航","朱佳乐"]

sentence_1 = "随机抽取，启动！"
for char in sentence_1:
    print(char, end="")
    if char in ["，", "！"]:
        sys.stdout.flush()
        time.sleep(0.5)
    else:
        time.sleep(0.1)
    
print("请选择运行选项：")
print("1. 英语课专用（无日语学生）")
print("2. 常规（全体学生）")

def get_choice():
    key = msvcrt.getch()

    if key == b'1':
        print("")
        print("当前处于：英语课专用的随机抽取(无日语学生)")
        e = students_1 
        d = input("请输入需要抽取的学生人数：")
        if d == "测试程序":
            def get_choice():
                key = msvcrt.getch()
                if key == b'1':
                    print("")
                    print("当前处于：英语课专用的随机抽取(无日语学生)")
                    e = students_1
                    print("")
                    b = int(input("请输入需要抽取的学生人數："))
                    c = 0
                    max_students = []
                    while c < b:
                        c += 1
                        selection_counts = {student: 0 for student in students}
                        a = random.randint(1000, 10000)
                        num_students = int(a)
                        counter = 0
                        max_iterations = num_students
                        while counter < max_iterations:
                            random_student = random.choice(students)
                            selection_counts[random_student] += 1
                            counter += 1
                        print("")
                    total_count = sum(selection_counts.values())
                    sorted_selection_counts = sorted(selection_counts.items(), key=lambda x: x[1])
                    for student, count in sorted_selection_counts:
                        percentage = count / total_count * 100
                        print(f"{student}: 被抽取次数：{count} 次 ；所占总数比例：({percentage:.3f}%)")
                    max_student, max_count = sorted_selection_counts[-1]
                    print("第", c, "次抽取结束！")
                    print("本次随机抽取的的随机抽取次數：", end="")
                    print(a, end="")
                    print("次")
                    print("以上是所有学生抽的取次数统计（从小到大排列）：")
                    print("本次被抽取次數最高的學生：", end="")
                    print(f"【{max_student}】；次數：{max_count} 次；百分比：{percentage:.3f}%")
                    time.sleep(1)
                    if max_student in max_students:
                        b += 1
                        print("")
                        print("抽取过程中出现重复学生，准备重新抽取")
                        max_students.append(max_student)
                    if max_students.count(max_student) > 1:
                        max_students.remove(max_student)
                print("")
                print("抽取结果：", max_students)
    
        elif key == b'2':
            e = students_2
            while True:
                print("")
                d = input("请输入需要抽取的学生人数：")
                sentence = "本程序的运行机制是，随机抽取一个学生，抽取一定次数（抽取次数是1千到1万的随机数）后，抽取完成之后，统计每个学生的被抽取次数、被抽取率（本次被抽取的次数与总抽取次数的百分比），选择被抽取次数最多的学生作为本次选中的学生。 输入需要的学生数量，就循环多少次"
                for char in sentence:
                    print(char, end="")
                    sys.stdout.flush()
                if char in ["，", "。", "（", "）"]:
                    time.sleep(0.1)
                else:
                    time.sleep(0.03)
    get_choice()
