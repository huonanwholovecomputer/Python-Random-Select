from cryptography.fernet import Fernet

# 读取密钥
with open('key.key', 'rb') as key_file:
    key = key_file.read()

# 读取加密的数据
with open('list2.enc', 'rb') as encrypted_file:
    encrypted_data = encrypted_file.read()

# 创建 Fernet 对象
fernet = Fernet(key)

# 解密数据
decrypted_data = fernet.decrypt(encrypted_data)

# 将解密后的数据转换回字符串
data = decrypted_data.decode()

# 将字符串数据转换回列表
list2 = data.split('\n')

print("Decrypted list2:", list2)
