import datetime
import os
from cryptography.fernet import Fernet

# 配置路径和文件名
program_data_storage_directory = os.path.join(os.path.expanduser("~"), "AppData", "Roaming", "Python_Random_Select")
Fernet_key_name = "Fernet_key.dll"
Fernet_key_path = os.path.join(program_data_storage_directory, Fernet_key_name)
encrypted_file_path = "recorded_students_file_path.enc"
selection_student = "霍楠"
now = datetime.datetime.now()
selection_student_and_now = selection_student + ' ' + now.strftime('%Y-%m-%d %H:%M:%S') + '\n'
print(selection_student_and_now)

# 加密
with open(Fernet_key_path, 'rb') as key_file:
    Fernet_key = key_file.read()
fernet = Fernet(Fernet_key)

encrypted_data = fernet.encrypt(selection_student_and_now.encode())

with open(encrypted_file_path, 'wb') as data_file:
    data_file.write(encrypted_data)

# 解密
with open(Fernet_key_path, 'rb') as key_file:
    Fernet_key = key_file.read()
fernet = Fernet(Fernet_key)

# 这部分要用'rb'模式读取加密文件
with open(encrypted_file_path, 'rb') as data_file:
    encrypted_data = data_file.read()

decrypted_data = fernet.decrypt(encrypted_data).decode()

# 拆分解密后的数据


name_and_timestamp = decrypted_data.strip().rsplit(' ', 2)
selection_student_decrypted = name_and_timestamp[0]
timestamp_decrypted = name_and_timestamp[1] + ' ' + name_and_timestamp[2]

print(f"学生: {selection_student_decrypted}")
print(f"时间: {timestamp_decrypted}")
