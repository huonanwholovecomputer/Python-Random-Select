print("√")
print("×")
