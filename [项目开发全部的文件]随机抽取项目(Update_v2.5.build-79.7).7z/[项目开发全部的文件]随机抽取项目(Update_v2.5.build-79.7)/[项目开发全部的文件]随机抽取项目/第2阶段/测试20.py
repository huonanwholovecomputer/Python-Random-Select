import random
from collections import Counter

elements = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']

m = int(input("請輸入累計個數m："))
counted_elements = set()

while len(counted_elements) < m:
    n = random.randint(50, 100)
    random_elements = random.choices(elements, k=n)
    element_counts = Counter(random_elements)

    total_occurrences = sum(element_counts.values())

    sorted_elements = sorted(element_counts.items(), key=lambda x: x[1], reverse=True)

    for element, count in sorted_elements:
        if element not in counted_elements:
            counted_elements.add(element)

        percentage = count / total_occurrences
        formatted_percentage = "{:.1%}".format(percentage)
        print(f"{element}: {count}；{formatted_percentage}")

    print("次數最高的元素:")
    for element, count in sorted_elements:
        if element not in counted_elements:
            continue

        print(f"【{element}】")
        counted_elements.remove(element)

    print("----------------")
