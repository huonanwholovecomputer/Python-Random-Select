import random
import time
import sys
students = ["學生1", "學生2", "學生3", "學生4", "學生5", "學生6"]
while True:
    d = input("请输入需要抽取的学生人數：")
# 如果输入"测试程序"，进入测试程序
    if d == "测试程序":
        print("")
        b = int(input("请输入需要抽取的学生人數："))
        c = 0
        max_students = []
        while c < b:
            c += 1
            selection_counts = {student: 0 for student in students}
            a = random.randint(1000, 10000)
            num_students = int(a)
            counter = 0
            max_iterations = num_students
            while counter < max_iterations:
                random_student = random.choice(students)
                selection_counts[random_student] += 1
                counter += 1
            print("")
            total_count = sum(selection_counts.values())
            sorted_selection_counts = sorted(selection_counts.items(), key=lambda x: x[1])
            for student, count in sorted_selection_counts:
                percentage = count / total_count * 100
                print(f"{student}: 被抽取次数：{count} 次 ；所占总数比例：({percentage:.3f}%)")
            max_student, max_count = sorted_selection_counts[-1]
            print("第", c, "次抽取结束！")
            print("本次随机抽取的的随机抽取次數：", end="")
            print(a, end="")
            print("次")
            print("以上是所有学生抽的取次数统计（从小到大排列）：")
            print("本次被抽取次數最高的學生：", end="")
            print(f"【{max_student}】；次數：{max_count} 次；百分比：{percentage:.3f}%")
            time.sleep(1)
            if max_student in max_students:
                b += 1
                print("")
                print("抽取过程中出现重复学生，准备重新抽取",end="")
                time.sleep(0.2)
                print(".",end="")
                time.sleep(0.2)
                print(".",end="")
                time.sleep(0.2)
                print(".")
                time.sleep(0.2)
            else:
                max_students.append(max_student)
            if max_students.count(max_student) > 1:
                max_students.remove(max_student)
        print("")
        print("抽取结果：", max_students)
# 如果输入非负整数
    elif d.isdigit():
        num_students_d = int(d)
        if num_students_d > len(students):
            print("")
            print("提示：抽取抽取数量超过学生总数！")
            time.sleep(1)
            print("")
            print("请重新抽取..")
            time.sleep(1.5)
        else:
          c = 0
          max_students = []
          while c < num_students_d:
            c += 1
            selection_counts = {student: 0 for student in students}
            a = random.randint(1000, 10000)
            num_students = int(a)
            counter = 0
            max_iterations = num_students
            while counter < max_iterations:
              random_student = random.choice(students)
              selection_counts[random_student] += 1
              counter += 1
            total_count = sum(selection_counts.values())
            sorted_selection_counts = sorted(selection_counts.items(), key=lambda x: x[1])
            for student, count in sorted_selection_counts:
                percentage = count / total_count * 100
            max_student, max_count = sorted_selection_counts[-1]
            if max_student in max_students:
                num_students_d += 1
            else:
                max_students.append(max_student)
            if max_students.count(max_student) > 1:
                max_students.remove(max_student)
          print("")
          print("抽取结果：", max_students)
#如果输入"?",显示程序运行机制。
    elif d =='？':
        sentence = "本程序的运行机制是，随机抽取一个学生，抽取一定次数（抽取次数是1千到1万的随机数）后，抽取完成之后，统计每个学生的被抽取次数、被抽取率（本次被抽取的次数与总抽取次数的百分比），选择被抽取次数最多的学生作为本次选中的学生。 输入需要的学生数量，就循环多少次"
        for char in sentence:
            print(char, end="")
            sys.stdout.flush()
            if char in ["，", "。", "（", "）"]:
                time.sleep(0.1)
            else:
                time.sleep(0.03)

        
