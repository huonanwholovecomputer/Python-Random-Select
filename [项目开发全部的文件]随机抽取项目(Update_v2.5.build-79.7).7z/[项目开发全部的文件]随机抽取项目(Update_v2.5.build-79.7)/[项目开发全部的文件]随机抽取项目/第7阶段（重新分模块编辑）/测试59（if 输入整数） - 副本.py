if d == "测试程序":
        print("")
        b = int(input("请输入需要抽取的学生人數："))
        c = 0
        max_students = []
        while c < b:
            c += 1
            selection_counts = {student: 0 for student in students}
            a = random.randint(1000, 10000)
            num_students = int(a)
            counter = 0
            max_iterations = num_students
            while counter < max_iterations:
                random_student = random.choice(students)
                selection_counts[random_student] += 1
                counter += 1
            print("")
            total_count = sum(selection_counts.values())
            sorted_selection_counts = sorted(selection_counts.items(), key=lambda x: x[1])
            for student, count in sorted_selection_counts:
                percentage = count / total_count * 100
                print(f"{student}: 被抽取次数：{count} 次 ；所占总数比例：({percentage:.3f}%)")
            max_student, max_count = sorted_selection_counts[-1]
            print("第", c, "次抽取结束！")
            print("本次随机抽取的的随机抽取次數：", end="")
            print(a, end="")
            print("次")
            print("以上是所有学生抽的取次数统计（从小到大排列）：")
            print("本次被抽取次數最高的學生：", end="")
            print(f"【{max_student}】；次數：{max_count} 次；百分比：{percentage:.3f}%")
            time.sleep(1)
            if max_student in max_students:
                b += 1
                print("")
                print("抽取过程中出现重复学生，准备重新抽取",end="")
                time.sleep(0.5)
                print(".",end="")
                time.sleep(0.5)
                print(".",end="")
                time.sleep(0.5)
                print(".")
                time.sleep(0.5)
            else:
                max_students.append(max_student)
            if max_students.count(max_student) > 1:
                max_students.remove(max_student)
            print("")
            print("抽取结果：", max_students)
