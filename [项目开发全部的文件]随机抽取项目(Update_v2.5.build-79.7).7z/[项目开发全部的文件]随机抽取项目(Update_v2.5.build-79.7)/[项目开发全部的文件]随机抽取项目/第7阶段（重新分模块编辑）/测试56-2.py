# 随机函数
import random
# 时间函数
import time
# 打字函数
import sys
# 选择函数
import msvcrt

# 英语专用名单
students_1 = ["白宇杰","陈玉","崔欣悦","崔知轩","窦可冉","高怡浩","郝浩然","郝晔妮","贺佳美","胡峰","霍俞达","雷航","雷淼","雷旭阳","李芊雨","李媛媛","李泽翔","刘杰","刘奕含","刘于楠","罗佳庚","马赫","马佳雪","马玲丹","马润杰","马谢楠","马跃","米庆","苗夏雨","任璠","王浩森","王浩宇","王慧娟","王美丹","王森","王文涛","王欣瑜","王玙贴","杨慧仪","袁博","张靖雨","张坤","张翔荣","张宇航","朱佳乐"]
# 所有学生名单
students_2 = ["白宇杰","陈玉","崔欣悦","崔知轩","窦可冉","冯宇乐","高怡浩","郝浩然","郝晔妮","贺佳美","胡峰","霍楠","霍俞达","雷航","雷淼","雷文杰","雷旭阳","李芊雨","李媛媛","李泽翔","刘杰","刘奕含","刘于楠","罗佳庚","马赫","马佳雪","马玲丹","马润杰","马谢楠","马跃","米庆","苗夏雨","任璠","王浩森","王浩宇","王慧娟","王美丹","王森","王文涛","王欣瑜","王玙贴","杨慧仪","袁博","张靖雨","张坤","张文杰","张翔荣","张宇航","朱佳乐"]

# 输出“随机抽取，启动！”
sentence = "随机抽取，启动！"
for char in sentence:
    print(char, end="")
    sys.stdout.flush()
    if char in ["，", "！"]:
        time.sleep(0.5)
    else:
        time.sleep(0.05)
# 选择函数部分：
def get_choice():
    while True:
        print("")
        print("请选择运行选项：")
        print("")
        print("1. 英语课专用（无日语学生）")
        print("")
        print("2. 常规（全体学生）")
        print("")
        print("3. 帮助（也可输入“？”、“?”）")
        key = msvcrt.getch()
        if key == b"1":  # 注意这里的比较值应为字节串
            print("")
            print("进入：英语课专用的随机抽取(无日语学生)")
            global students  # 使用 global 关键字声明全局变量
            students = students_1
            break
        elif key == b"2":  # 注意这里的比较值应为字节串
            print("")
            print("进入：常规随机抽取(全体学生)")
            students = students_2
            break
        elif key == b"3"or"?"or"？":
            print("")
            print("帮助：输入1或者2，进入指定的抽取模式")
            print("")
            time.sleep(1)
        else:
            print("")
            print("无效选择！")
            time.sleep(1)
            print("")
            print("请重新选择！")
            time.sleep(0.5)
    
get_choice()  # 调用 get_choice() 函数

#循环部分
while True:
    print("")
# 如果输入"测试程序"，进入测试程序
    d = input("请输入需要抽取的学生人数：")
    if d == "测试程序":
        print("")
        print("进入：测试程序")
        print("")
        b = int(input("请输入需要抽取的学生人數："))
        c = 0
        max_students = []
        while c < b:
            c += 1
            selection_counts = {student: 0 for student in students}
            a = random.randint(1000, 10000)
        num_students = int(a)
        counter = 0
        max_iterations = num_students
        while counter < max_iterations:
            random_student = random.choice(students)
            selection_counts[random_student] += 1
            counter += 1
        print("")
        total_count = sum(selection_counts.values())
        sorted_selection_counts = sorted(selection_counts.items(), key=lambda x: x[1])
        for student, count in sorted_selection_counts:
            percentage = count / total_count * 100
            print(f"{student}: 被抽取次数：{count} 次 ；所占总数比例：({percentage:.3f}%)")
        max_student, max_count = sorted_selection_counts[-1]
        print("第", c, "次抽取结束！")
        print("本次随机抽取的的随机抽取次數：", end="")
        print(a, end="")
        print("次")
        print("以上是所有学生抽的取次数统计（从小到大排列）：")
        print("本次被抽取次數最高的學生：", end="")
        print(f"【{max_student}】；次數：{max_count} 次；百分比：{percentage:.3f}%")
        time.sleep(1)
        if max_student in max_students:
            num_students_d += 1
            b += 1
            print("")
            print("抽取过程中出现重复学生，准备重新抽取",end="")
            time.sleep(0.2)
            print(".",end="")
            time.sleep(0.2)
            print(".",end="")
            time.sleep(0.2)
            print(".")
            time.sleep(0.2)
        else:
            max_students.append(max_student)
        if max_students.count(max_student) > 1:
            max_students.remove(max_student)
        print("")
        print("抽取结果：", max_students)
        
# 如果输入非负整数
    elif d.isdigit():
        num_students_d = int(d)
        if num_students_d > len(students):
            print("")
            print("提示：抽取抽取数量超过学生总数！")
            time.sleep(1)
            print("")
            print("请重新抽取..")
            time.sleep(1.5)
        else:
          c = 0
          max_students = []
          while c < num_students_d:
            c += 1
            selection_counts = {student: 0 for student in students}
            a = random.randint(1000, 10000)
            num_students = int(a)
            counter = 0
            max_iterations = num_students
            while counter < max_iterations:
              random_student = random.choice(students)
              selection_counts[random_student] += 1
              counter += 1
            total_count = sum(selection_counts.values())
            sorted_selection_counts = sorted(selection_counts.items(), key=lambda x: x[1])
            for student, count in sorted_selection_counts:
                percentage = count / total_count * 100
            max_student, max_count = sorted_selection_counts[-1]
            if max_student in max_students:
                num_students_d += 1
            else:
                max_students.append(max_student)
            if max_students.count(max_student) > 1:
                max_students.remove(max_student)
          print("")
          print("抽取结果：", max_students)
          
# 如果输入"?",显示程序运行机制。
    elif d =='？':
        print("")
        sentence = "本程序的运行机制是，随机抽取一个学生，抽取一定次数（抽取次数是1千到1万的随机数）后，抽取完成之后，统计每个学生的被抽取次数、被抽取率（本次被抽取的次数与总抽取次数的百分比），选择被抽取次数最多的学生作为本次选中的学生。 输入需要的学生数量，就循环多少次"
        for char in sentence:
            print(char, end="")
            sys.stdout.flush()
            if char in ["，", "。", "（", "）"]:
                time.sleep(0.1)
            else:
                time.sleep(0.03)
        print("")
    else:
        print("请输入有效命令！")
        time.sleep(0.5)
        print("1.可输入数字，抽取指定的学生人数")
        time.sleep(0.5)
        print("2.可输入“？”或“?”查看当前程序位置的帮助")
        time.sleep(0.5)
        print("3.可输入“测试程序”显示程序在进行随机抽取时的详细运行过程")
        time.sleep(0.5)

        
