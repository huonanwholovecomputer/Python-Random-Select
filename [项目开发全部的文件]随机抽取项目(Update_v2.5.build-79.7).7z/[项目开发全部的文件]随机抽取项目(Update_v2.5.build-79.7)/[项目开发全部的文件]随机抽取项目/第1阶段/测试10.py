import random

students = ["學生1", "學生2", "學生3", "學生4", "學生5", "學生6"]
counter = 0

while counter < 50:
    num_students = int(input("輸入要隨機選擇的學生數目："))

    if num_students <= len(students):
        random_students = random.sample(students, num_students)
        print("循環次數:", counter+1)
        print("隨機本次抽取的學生：", random_students)
    else:
        break

    counter += 1
