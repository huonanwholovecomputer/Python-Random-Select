import random
import time
import sys
import msvcrt

def print_slowly(sentence, delay=0.05):
    for char in sentence:
        print(char, end="")
        sys.stdout.flush()
        time.sleep(delay)

def get_choice(students_1, students_2):
    while True:
        print("\n---------------------------------------------")
        print("请选择运行选项：\n")
        time.sleep(0.1)
        print("【1】 英语课专用（无日语学生）\n")
        time.sleep(0.1)
        print("【2】 常规（全体学生）\n")
        time.sleep(0.1)
        print("【3】 帮助（也可输入“？”、“?”）")
        print("---------------------------------------------")
        key = msvcrt.getch()
        if key == b'1':
            print_slowly("已选择【1】，进入：英语课专用的随机抽取(无日语学生)")
            time.sleep(0.5)
            students = students_1
            print(f"\n\n本名单总人数：{len(students)}\n")
            time.sleep(1)
            break
        elif key == b'2':
            print_slowly("已选择【2】，进入：常规随机抽取(全体学生)")
            time.sleep(0.5)
            students = students_2
            print(f"\n\n本名单总人数：{len(students)}\n")
            time.sleep(1)
            break
        elif key in [b'3', b'?']:
            print("\n---------------------------------------------")
            print_slowly("已选择【3】，帮助：输入1或者2，进入指定的抽取模式\n")
            time.sleep(1)
        else:
            print("\n无效选择！\n请重新选择！")
            time.sleep(1)

    return students

def random_selection(students, num_students_d):
    for _ in range(num_students_d):
        selection_counts = {student: 0 for student in students}
        num_students = random.randint(10000, 100000)
        for _ in range(num_students):
            random_student = random.choice(students)
            selection_counts[random_student] += 1
        total_count = sum(selection_counts.values())
        sorted_selection_counts = sorted(selection_counts.items(), key=lambda x: x[1])
        max_student, max_count = sorted_selection_counts[-1]
        print(f"抽取结果：{max_student}")
        time.sleep(1)

def main():
    students_1 = ["白宇杰","陈俊昌","陈玉","崔欣悦","崔知轩","窦可冉","高怡浩","韩敬哲","韩怡悦","郝浩然","郝晔妮","贺佳美","胡峰","霍楠","霍俞达","雷航","雷淼","雷旭阳","李芊雨","李媛媛","李泽翔","刘杰","刘奕含","刘于楠","马赫","马佳雪","马玲丹","马润杰","马谢楠","马跃","米庆","苗夏雨","任璠","王浩森","王浩宇","王慧娟","王美丹","王森","王文涛","王欣瑜","王玙贴","杨慧仪","袁博","张靖雨","张坤","张翔荣","张宇航","张雨萌","朱佳乐"]  # 英语专用名单
    students_2 = ["白宇杰","陈俊昌","陈玉","崔欣悦","崔知轩","窦可冉","冯宇乐","高怡浩","韩敬哲","韩怡悦","郝浩然","郝晔妮","贺佳美","胡峰","霍楠","霍俞达","雷航","雷淼","雷文杰","雷旭阳","李芊雨","李媛媛","李泽翔","刘杰","刘奕含","刘于楠","马赫","马佳雪","马玲丹","马润杰","马谢楠","马跃","米庆","苗夏雨","任璠","王浩森","王浩宇","王慧娟","王美丹","王森","王文涛","王欣瑜","王玙贴","杨慧仪","袁博","张靖雨","张坤","张文杰","张翔荣","张宇航","张雨萌","朱佳乐"]  # 所有学生名单

    print_slowly("随机抽取，启动！")
    students = get_choice(students_1, students_2)

    while True:
        print("")
        d = input("需要抽取的学生个数：")
        print("")

        if d.isdigit():
            num_students_d = int(d)
            if num_students_d > len(students):
                print("提示：需要抽取的学生个数超过学生总数！")
                time.sleep(1)
            else:
                random_selection(students, num_students_d)
        elif d in ["测试程序", "cscx"]:
            testing_mode()
        elif d in ["?", "？"]:
            print_help()
        else:
            print("\n*请输入有效命令！\n1.可输入数字，抽取指定的学生人数\n2.可输入“？”或“?”查看当前程序位置的帮助\n3.可输入“测试程序”或“cscx”显示程序在进行随机抽取时的详细运行过程")
            time.sleep(1)

if __name__ == "__main__":
    main()
