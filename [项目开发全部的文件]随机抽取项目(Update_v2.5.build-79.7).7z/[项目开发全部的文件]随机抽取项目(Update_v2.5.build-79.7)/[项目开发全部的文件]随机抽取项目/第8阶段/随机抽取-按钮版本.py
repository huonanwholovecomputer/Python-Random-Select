# 随机函数
import random
# 时间函数
import time
# 打字函数
import sys
# 选择函数
import msvcrt
#Windows按钮函数
import tkinter as tk
# 英语专用名单
students_1 = ["白宇杰","陈俊昌","陈玉","崔欣悦","崔知轩","窦可冉","高怡浩","韩敬哲","韩怡悦","郝浩然","郝晔妮","贺佳美","胡峰","霍楠","霍俞达","雷航","雷淼","雷旭阳","李芊雨","李媛媛","李泽翔","刘杰","刘奕含","刘于楠","马赫","马佳雪","马玲丹","马润杰","马谢楠","马跃","米庆","苗夏雨","任璠","王浩森","王浩宇","王慧娟","王美丹","王森","王文涛","王欣瑜","王玙贴","杨慧仪","袁博","张靖雨","张坤","张翔荣","张宇航","朱佳乐"]
# 所有学生名单
students_2 = ["白宇杰","陈俊昌","陈玉","崔欣悦","崔知轩","窦可冉","冯宇乐","高怡浩","韩敬哲","韩怡悦","郝浩然","郝晔妮","贺佳美","胡峰","霍楠","霍俞达","雷航","雷淼","雷文杰","雷旭阳","李芊雨","李媛媛","李泽翔","刘杰","刘奕含","刘于楠","马赫","马佳雪","马玲丹","马润杰","马谢楠","马跃","米庆","苗夏雨","任璠","王浩森","王浩宇","王慧娟","王美丹","王森","王文涛","王欣瑜","王玙贴","杨慧仪","袁博","张靖雨","张坤","张文杰","张翔荣","张宇航","朱佳乐"]
# 输出“随机抽取，启动！”
sentence = "随机抽取，启动！"
for char in sentence:
    print(char, end="")
    sys.stdout.flush()
    if char in ["，", "！"]:
        time.sleep(0.5)
    else:
        time.sleep(0.05)
# 选择函数部分：
def get_choice():
    global students
    while True:
        print("")
        print("---------------------------------------------")
        print("请选择运行选项：")
        print("")
        time.sleep(0.1)
        print("【1】 英语课专用（无日语学生）")
        print("")
        time.sleep(0.1)
        print("【2】 常规（全体学生）")
        print("")
        time.sleep(0.1)
        print("【3】 帮助（也可输入“？”、“?”）")
        print("---------------------------------------------")
        key = msvcrt.getch()
        if key == b"1":
            time.sleep(0.25)
            sentence = "已选择【1】，进入：英语课专用的随机抽取(无日语学生)"
            for char in sentence:
                print(char, end="")
                sys.stdout.flush()
                time.sleep(0.05)
            time.sleep(0.5)
            students = students_1
            print("")
            print("")
            print("本名单总人数：", end="")
            print(len(students))
            time.sleep(1)
            break
        elif key == b"2":
            time.sleep(0.25)
            sentence = "已选择【2】，进入：常规随机抽取(全体学生)"
            for char in sentence:
                print(char, end="")
                sys.stdout.flush()
                time.sleep(0.05)
            time.sleep(0.5)
            students = students_2
            print("")
            print("")
            print("本名单总人数：", end="")
            print(len(students))
            time.sleep(1)
            break
        elif key == b"3" or key == b"?" or key == "？":
            print("")
            print("---------------------------------------------")
            sentence = "已选择【3】，帮助：输入1或者2，进入指定的抽取模式"
            for char in sentence:
                print(char, end="")
                sys.stdout.flush()
                time.sleep(0.05)
            print("")
            time.sleep(1)
        else:
            print("")
            print("无效选择！")
            time.sleep(0.5)
            print("")
            print("请重新选择！")
            time.sleep(0.5)
    
get_choice()  # 调用 get_choice() 函数

a = 0

def pick_student():
    global a
    a += 1
    selected_student = random.choice(students)
    result_label.config(text="抽取结果：" + selected_student)
    print("")
    print("第", a, "次的抽取结果：",end="")
    print(selected_student)

window = tk.Tk()
window.title("学生抽取程序")

button = tk.Button(window, text="开始抽取", command=pick_student)
button.pack(pady=10)

result_label = tk.Label(window, text="")
result_label.pack()

window.mainloop()
