import random
import time

# 英语专用名单
students = ["白宇杰","陈俊昌","陈玉","崔欣悦","崔知轩","窦可冉","高怡浩","韩敬哲","韩怡悦","郝浩然","郝晔妮","贺佳美","胡峰","霍楠","霍俞达","雷航","雷淼","雷旭阳","李芊雨","李媛媛","李泽翔","刘杰","刘奕含","刘于楠","马赫","马佳雪","马玲丹","马润杰","马谢楠","马跃","米庆","苗夏雨","任璠","王浩森","王浩宇","王慧娟","王美丹","王森","王文涛","王欣瑜","王玙贴","杨慧仪","袁博","张靖雨","张坤","张翔荣","张宇航","朱佳乐","张雨萌"]  # 示例学生名单，实际应用中可能需要更长的名单

while True:
    print("")
    d = input("需要抽取的学生个数：")
    print("")
    
    # 如果输入非负整数
    if d.isdigit() and int(d) > 0:
        num_students_d = int(d)
        if num_students_d > len(students):
            print("提示：需要抽取的学生个数超过学生总数！")
            time.sleep(0.5)
            print("")
            print("请重新抽取..")
            time.sleep(1)
        else:
            # 初始化学生选择次数字典
            #导入
            c = 0
            max_students = []
            while c < num_students_d:
                c += 1
                selection_counts = {student: 0 for student in students}
                a = random.randint(10000, 100000)
                num_students = int(a)
                counter = 0
                max_iterations = num_students
                while counter < max_iterations:
                    random_student = random.choice(students)
                    selection_counts[random_student] += 1
                    counter += 1
                total_count = sum(selection_counts.values())
                sorted_selection_counts = sorted(selection_counts.items(), key=lambda x: x[1], reverse=True)
                for student, count in sorted_selection_counts:
                    percentage = count / total_count * 100
                    max_student, max_count = sorted_selection_counts[-1]
                    if max_student in max_students:
                        num_students_d += 1
                    else:
                        max_students.append(max_student)
                if max_students.count(max_student) > 1:
                    max_students.remove(max_student)
            # 生成一个介于1到学生总数之间的随机数x
            x = random.randint(1, len(students))
            # 获取排名为x的学生
            if len(sorted_selection_counts) >= x:
                xth_student, xth_count = sorted_selection_counts[x - 1]
                print(f"被选中次数排名为第{x}名的学生是：{xth_student}, 被选中次数为：{xth_count}")
            else:
                print("学生人数不足以确定第x名的选中次数。")
    else:
        print("请输入一个正整数。")
